RUN_PARTS <- c(1L, 2L)
ONLY_PLOT <- FALSE
PROJECT_DIR <- file.path(getwd(), "KTH_TIPS2b_SQP")

cfg <- list(
  project_dir = PROJECT_DIR,
  raw_dir = file.path(PROJECT_DIR, "data"),
  archive = file.path(PROJECT_DIR, "downloads", "kth-tips2-b_col_200x200.tar"),
  download_url = paste0("https://www.csc.kth.se/cvap/databases/kth-tips/",
                        "kth-tips2-b_col_200x200.tar"),
  materials = c("corduroy", "linen"),
  samples = c("a", "b", "c", "d"),
  scales = 5L,
  image_numbers = c(1L, 2L, 3L, 10L),
  patch_size = 64L,

  border_fraction = 0.10,
  min_patch_sd = 1 / 255,
  max_saturated_fraction = 0.10,
  max_single_gray_fraction = 0.20,
  max_flat_border_run = 4L,

  detrend = "mean",                 
  alphas = c(SQP01 = 0.1, SQP05 = 0.5, SQP09 = 0.9),
  chunk_size = 32L,                 
  low_frequency_cut = 0L,           
  jsd_halfwidth = 1L,               
  log_floor = 1e-10,
  force_recompute = FALSE,
  auto_install = TRUE,
  phi = 30, theta = 20,
  plot_types = c("raw", "log_normalized"),
  make_heatmaps = TRUE,
  make_profiles = TRUE,
  estimator_version = "KTH-spatial-QR-v1"
)

kth_require <- function(packages, install = cfg$auto_install) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) && install)
    install.packages(missing, repos = "https://cloud.r-project.org")
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Install required packages: ", paste(missing, collapse = ", "),
                            ". If CRAN requires a newer R/Matrix, update R first.")
}
kth_dirs <- function(cfg) {
  for (d in c(cfg$project_dir, cfg$raw_dir, dirname(cfg$archive),
              file.path(cfg$project_dir, c("tables", "figures", "cache"))))
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}
kth_csv <- function(x, name, cfg) {
  write.csv(x, file.path(cfg$project_dir, "tables", name), row.names = FALSE, na = "")
}
kth_hash <- function(x) {
  f <- tempfile(); on.exit(unlink(f), add = TRUE)
  saveRDS(x, f, version = 2, compress = FALSE)
  unname(tools::md5sum(f))
}
kth_save_rds <- function(x, file) {
  f <- tempfile(tmpdir = dirname(file)); on.exit(unlink(f), add = TRUE)
  saveRDS(x, f, compress = TRUE)
  if (file.exists(file)) unlink(file)
  if (!file.rename(f, file)) stop("Cannot save ", file)
}
kth_load <- function(file, object) {
  if (!file.exists(file)) stop("Missing ", file, ". Run the preceding part first.")
  e <- new.env(parent = emptyenv()); load(file, envir = e)
  if (!exists(object, e, inherits = FALSE)) stop("Unexpected RData contents: ", file)
  get(object, e, inherits = FALSE)
}
kth_light_map <- function() data.frame(
  image_number = 1:12,
  pose = c(rep("front", 3), rep("right22.5", 3), rep("left22.5", 3),
           "front", "right22.5", "left22.5"),
  illumination = c(rep(c("Front", "Top", "Side"), 3), rep("Ambient", 3)),
  stringsAsFactors = FALSE)
kth_key <- function(d) paste(d$material, d$sample, d$scale, d$image_number, sep = "_")

kth_index <- function(paths) {
  paths <- gsub("\\\\", "/", paths)
  pat <- "(?:^|/)(corduroy|linen)/sample_([a-d])/[^/]*scale_([0-9]+)_im_([0-9]+)_col[.]png$"
  hits <- regmatches(paths, regexec(pat, paths, perl = TRUE))
  good <- lengths(hits) == 5L
  if (!any(good)) return(data.frame())
  z <- hits[good]
  out <- data.frame(path = paths[good],
                    material = vapply(z, `[`, "", 2L),
                    sample = vapply(z, `[`, "", 3L),
                    scale = as.integer(vapply(z, `[`, "", 4L)),
                    image_number = as.integer(vapply(z, `[`, "", 5L)),
                    stringsAsFactors = FALSE)
  lm <- kth_light_map(); j <- match(out$image_number, lm$image_number)
  if (anyNA(j)) stop("Unexpected image numbers in the archive.")
  out$pose <- lm$pose[j]; out$illumination <- lm$illumination[j]
  out$image_id <- kth_key(out)
  out
}
kth_requested <- function(cfg) {
  z <- expand.grid(material = cfg$materials, sample = cfg$samples,
                   scale = cfg$scales, image_number = cfg$image_numbers,
                   stringsAsFactors = FALSE)
  z[order(match(z$material, cfg$materials), match(z$sample, cfg$samples),
          z$scale, match(z$image_number, cfg$image_numbers)), ]
}
kth_pick <- function(index, cfg, fail = TRUE) {
  wanted <- kth_requested(cfg)
  if (!nrow(index)) {
    if (fail) stop("No KTH Corduroy / Linen files found.") else return(NULL)
  }
  if (anyDuplicated(index$image_id)) stop("Duplicate image identifiers in data directory.")
  j <- match(kth_key(wanted), index$image_id)
  if (anyNA(j)) {
    if (fail) stop("Requested images are missing: ",
                   paste(kth_key(wanted)[is.na(j)], collapse = ", "))
    return(NULL)
  }
  ans <- index[j, ]; rownames(ans) <- NULL; ans
}
kth_get_data <- function(cfg) {
  local_index <- kth_index(list.files(cfg$raw_dir, "[.]png$", recursive = TRUE,
                                      full.names = TRUE, ignore.case = TRUE))
  local_selected <- kth_pick(local_index, cfg, fail = FALSE)
  if (!is.null(local_selected)) return(local_selected)
  if (!file.exists(cfg$archive)) {
    old <- options(timeout = max(3600, getOption("timeout")))
    on.exit(options(old), add = TRUE)
    tmp <- paste0(cfg$archive, ".part")
    message("Downloading the official KTH-TIPS2-b archive (about 386 MB)...")
    status <- tryCatch(download.file(cfg$download_url, tmp, mode = "wb", method = "libcurl"),
                       error = function(e) e)
    if (inherits(status, "error") || !identical(as.integer(status), 0L))
      stop("Download failed. Download the official tar manually to: ", cfg$archive,
           " ; or place the extracted KTH-TIPS2-b tree under ", cfg$raw_dir,
           if (inherits(status, "error")) paste0("\n", conditionMessage(status)) else "")
    if (!file.rename(tmp, cfg$archive)) stop("Cannot rename downloaded archive.")
  }
  members <- tryCatch(utils::untar(cfg$archive, list = TRUE, tar = "internal"),
                      error = function(e) stop("Cannot read archive: ", conditionMessage(e)))
  selected <- kth_pick(kth_index(members), cfg)
  if (any(grepl("(^/|^[A-Za-z]:|(^|/)[.][.](/|$))", selected$path)))
    stop("Unsafe archive paths.")
  message("Extracting only ", nrow(selected), " selected PNG images...")

  status <- utils::untar(cfg$archive, files = selected$path, exdir = cfg$raw_dir,
                         tar = "internal")
  selected$path <- file.path(cfg$raw_dir, selected$path)
  if (status != 0L || !all(file.exists(selected$path))) stop("Image extraction failed.")
  selected
}
kth_documented_blur <- function(d) {

  with(d, material == "corduroy" &
         ((sample == "b" & scale == 5L & image_number == 11L) |
          (sample == "b" & scale == 6L & image_number == 2L) |
          (sample == "c" & scale == 8L & image_number %in% c(1:6, 10:11)) |
          (sample == "c" & scale == 9L & image_number %in% 4:6) |
          (sample == "c" & scale == 10L & image_number == 6L)))
}
kth_gray <- function(path) {
  a <- png::readPNG(path)
  if (length(dim(a)) == 2L) y <- a else {
    if (dim(a)[3L] < 3L) stop("Unsupported PNG channels: ", path)
    if (dim(a)[3L] == 4L && any(a[, , 4L] < 1)) stop("Transparent PNG: ", path)
    y <- 0.299*a[, , 1L] + 0.587*a[, , 2L] + 0.114*a[, , 3L]
  }
  if (any(!is.finite(y)) || min(y) < -1e-8 || max(y) > 1 + 1e-8)
    stop("Invalid image values: ", path)
  y
}
kth_longest_run <- function(x) {
  r <- rle(x); if (any(r$values)) max(r$lengths[r$values]) else 0L
}
kth_quality <- function(y, cfg) {
  saturated <- mean(y <= 0.5/255 | y >= 254.5/255)
  modal <- max(tabulate(as.integer(round(y*255)) + 1L, nbins = 256L)) / length(y)
  flatrow <- apply(y, 1, sd) <= 0.25/255 & (rowMeans(y) < .01 | rowMeans(y) > .99)
  flatcol <- apply(y, 2, sd) <= 0.25/255 & (colMeans(y) < .01 | colMeans(y) > .99)
  run <- max(kth_longest_run(flatrow), kth_longest_run(flatcol))
  s <- sd(as.vector(y))
  reasons <- c(if (s < cfg$min_patch_sd) "near_constant",
               if (saturated > cfg$max_saturated_fraction) "saturation",
               if (modal > cfg$max_single_gray_fraction) "large_gray_plateau",
               if (run > cfg$max_flat_border_run) "flat_extreme_band")
  data.frame(sd = s, saturation_fraction = saturated, modal_gray_fraction = modal,
             flat_band_run = run, ok = !length(reasons),
             reason = paste(reasons, collapse = ";"), stringsAsFactors = FALSE)
}
kth_crop <- function(y, anchor, cfg) {
  L <- cfg$patch_size; nr <- nrow(y); nc <- ncol(y)
  r <- as.integer(round(anchor[1]*(nr-1) + 1 - (L-1)/2))
  c <- as.integer(round(anchor[2]*(nc-1) + 1 - (L-1)/2))
  border <- ceiling(cfg$border_fraction * c(nr, nc))
  if (r <= border[1] || c <= border[2] ||
      r+L-1 > nr-border[1] || c+L-1 > nc-border[2]) return(NULL)
  list(Y = y[r + seq_len(L)-1L, c + seq_len(L)-1L, drop = FALSE],
       row_start = r, col_start = c)
}
kth_detrend <- function(y, method) {
  if (method == "mean") return(y - mean(y))
  if (method == "plane") {
    s <- expand.grid(row = seq_len(nrow(y)), col = seq_len(ncol(y)))
    return(matrix(lm.fit(cbind(1, scale(s$row), scale(s$col)), as.vector(y))$residuals,
                  nrow(y), ncol(y)))
  }
  stop("detrend must be 'mean' or 'plane'.")
}
kth_image <- function(y, main = "", box = NULL) {
  nr <- nrow(y); nc <- ncol(y)
  op <- par(pty = "s"); on.exit(par(op), add = TRUE)
  image(seq_len(nc), seq_len(nr), t(y[nr:1L, , drop = FALSE]),
        col = gray.colors(256, start = 0, end = 1), zlim = c(0, 1),
        axes = FALSE, xlab = "", ylab = "", asp = 1, useRaster = TRUE, main = main,
        xlim = c(.5,nc+.5), ylim = c(.5,nr+.5), xaxs = "i", yaxs = "i")
  if (!is.null(box)) rect(box[2]-.5, nr-(box[1]+box[3]-1)+.5,
                         box[2]+box[3]-.5, nr-box[1]+1.5, border = "red", lwd = 1.5)
  graphics::box()
}
kth_plot_preprocessing <- function(prep, cfg) {
  for (material in unique(prep$meta$material)) {
    for (kind in c("roi_audit", "image_patches")) {
      f <- file.path(cfg$project_dir, "figures", paste0(kind, "_", material, ".pdf"))
      grDevices::pdf(f, width = 11, height = 10, onefile = TRUE)
      tryCatch({
        for (sc in unique(prep$meta$scale)) {
          ii <- which(prep$meta$material == material & prep$meta$scale == sc)
          nc <- length(unique(prep$meta$image_number[ii])); nr <- length(unique(prep$meta$sample[ii]))
          par(mfrow = c(nr, nc), mar = c(.5, .2, 2.8, .2), oma = c(0, 0, 2, 0))
          for (i in ii) {
            m <- prep$meta[i, ]; id <- m$image_id
            if (kind == "roi_audit") {
              y <- prep$images[[id]]; b <- c(m$row_start, m$col_start, cfg$patch_size)
            } else { y <- prep$gray_patches[[id]]; b <- NULL }
            kth_image(y, sprintf("Sample %s | %s", toupper(m$sample), m$illumination), b)
          }
          mtext(sprintf("%s | scale %d | %s", material, sc, kind), outer = TRUE, font = 2)
        }
      }, finally = dev.off())
    }
  }
}
kth_part1 <- function(cfg) {
  kth_dirs(cfg); kth_require("png", cfg$auto_install)
  if (!all(cfg$materials %in% c("corduroy", "linen")) ||
      !all(cfg$samples %in% letters[1:4]) || !all(cfg$scales %in% 2:10) ||
      !all(cfg$image_numbers %in% c(1L,2L,3L,10L)) || !1L %in% cfg$image_numbers)
    stop("Select Corduroy/Linen, samples a-d, scales 2-10 and frontal IDs 1/2/3/10 (include 1).")
  if (cfg$patch_size < 8L || cfg$patch_size != as.integer(cfg$patch_size))
    stop("patch_size must be an integer >= 8.")
  meta <- kth_get_data(cfg)
  meta$documented_blur <- kth_documented_blur(meta)
  kth_csv(meta, "selected_images.csv", cfg)
  if (any(meta$documented_blur)) stop("Selected combination includes documented blurred images. ",
                                     "See selected_images.csv; the default scale 5 avoids them.")
  images <- setNames(lapply(meta$path, kth_gray), meta$image_id)
  meta$height <- vapply(images, nrow, integer(1)); meta$width <- vapply(images, ncol, integer(1))
  meta$md5 <- unname(tools::md5sum(meta$path))
  meta$row_start <- meta$col_start <- NA_integer_
  meta$anchor_row <- meta$anchor_col <- NA_real_
  anchors <- rbind(c(.5,.5), c(.4,.5), c(.6,.5), c(.5,.4), c(.5,.6),
                   c(.4,.4), c(.4,.6), c(.6,.4), c(.6,.6))
  groups <- split(seq_len(nrow(meta)), paste(meta$material, meta$sample, meta$scale, sep = "_"))
  gray_patches <- patches <- vector("list", nrow(meta))
  names(gray_patches) <- names(patches) <- meta$image_id
  quality <- attempts <- list()
  for (g in names(groups)) {
    ii <- groups[[g]]; chosen <- NULL
    for (a in seq_len(nrow(anchors))) {
      crops <- lapply(ii, function(i) kth_crop(images[[i]], anchors[a, ], cfg))
      if (any(vapply(crops, is.null, logical(1)))) next
      q <- do.call(rbind, lapply(crops, function(z) kth_quality(z$Y, cfg)))
      attempts[[length(attempts)+1L]] <- cbind(group = g, anchor = a, image_id = meta$image_id[ii], q)
      if (all(q$ok)) { chosen <- list(crops = crops, q = q, a = a); break }
    }
    if (is.null(chosen)) {
      if (length(attempts)) kth_csv(do.call(rbind, attempts), "crop_attempts.csv", cfg)
      stop("No common acceptable interior crop for ", g,
           ". Inspect crop_attempts.csv and original images; no spectral-based selection is used.")
    }
    for (j in seq_along(ii)) {
      i <- ii[j]; z <- chosen$crops[[j]]
      meta$row_start[i] <- z$row_start; meta$col_start[i] <- z$col_start
      meta$anchor_row[i] <- anchors[chosen$a,1]; meta$anchor_col[i] <- anchors[chosen$a,2]
      gray_patches[[i]] <- z$Y; patches[[i]] <- kth_detrend(z$Y, cfg$detrend)
    }
    quality[[g]] <- cbind(image_id = meta$image_id[ii], chosen$q)
  }
  prep <- list(version = "KTH-prep-v1", created = as.character(Sys.time()), config = cfg,
               meta = meta, images = images, gray_patches = gray_patches, patches = patches,
               qc = do.call(rbind, quality), source_url = cfg$download_url,
               notes = c("Repeated images of each physical sample are not independent samples.",
                         "Central relative crop; no image registration across lighting conditions.",
                         "QC is heuristic: inspect roi_audit and image_patches PDFs."))
  prep$signature <- kth_hash(list(meta[,setdiff(names(meta), "path")], patches, cfg$detrend))
  save(prep, file = file.path(cfg$project_dir, "KTH_preprocessed.RData"), compress = "xz")
  kth_csv(meta, "selected_images.csv", cfg)
  kth_csv(prep$qc, "patch_QC.csv", cfg)
  kth_csv(do.call(rbind, attempts), "crop_attempts.csv", cfg)
  kth_plot_preprocessing(prep, cfg)
  message("Part 1 complete: ", nrow(meta), " images, ", cfg$patch_size, " x ", cfg$patch_size,
          " patches. Inspect figures/roi_audit_*.pdf before interpreting spectra.")
  invisible(prep)
}

if (isTRUE(getOption("kth.sqp.autorun", TRUE)) && 1L %in% RUN_PARTS) kth_part1(cfg)

kth_design <- function(n1, n2) {

  loc <- expand.grid(s1 = seq_len(n1), s2 = seq_len(n2))
  f <- expand.grid(nu1 = 0:(n1-1L), nu2 = 0:(n2-1L))
  f$neg1 <- (-f$nu1) %% n1; f$neg2 <- (-f$nu2) %% n2
  self <- f$nu1 == f$neg1 & f$nu2 == f$neg2
  keep <- !self & f$nu1*n2 + f$nu2 < f$neg1*n2 + f$neg2
  f <- f[keep, ]; rownames(f) <- NULL
  f$omega1 <- 2*pi*f$nu1/n1; f$omega2 <- 2*pi*f$nu2/n2
  list(n1 = n1, n2 = n2, N = n1*n2, locations = loc, freq = f, m = nrow(f))
}

spatial_pg <- function(y, design) {
  y <- as.numeric(y)
  if (length(y) != design$N) stop("The length of y does not agree with the lattice size.")
  z_re <- as.vector(crossprod(design$Cmat, y))
  z_im <- -as.vector(crossprod(design$Smat, y))
  (z_re^2 + z_im^2) / design$N
}
spatial_qp <- function(y, design, alpha = 0.8) {
  y <- as.numeric(y)
  if (length(y) != design$N) stop("The length of y does not agree with the lattice size.")
  ans <- numeric(design$m)
  for (j in seq_len(design$m)) {
    X <- cbind(1, design$Cmat[,j], design$Smat[,j])
    beta <- tryCatch(
      quantreg::rq.fit.fnb(x = X, y = y, tau = alpha)$coefficients,
      error = function(e) quantreg::rq.fit.br(x = X, y = y, tau = alpha)$coefficients)
    ans[j] <- design$N * (beta[2L]^2 + beta[3L]^2) / 4
  }
  ans
}
periodogram_to_full_matrix <- function(values, design) {
  if (length(values) != design$m) stop("Spectrum length does not match design.")
  Z <- matrix(NA_real_, design$n1, design$n2)
  Z[cbind(design$freq$nu1+1L, design$freq$nu2+1L)] <- values
  Z[cbind(design$freq$neg1+1L, design$freq$neg2+1L)] <- values
  Z
}
center_periodogram_matrix <- function(values, design, normalize = TRUE) {
  if (normalize) values <- values / mean(values)
  Z <- periodogram_to_full_matrix(values, design)
  f1 <- (0:(design$n1-1L))/design$n1; f2 <- (0:(design$n2-1L))/design$n2
  f1[f1 >= .5] <- f1[f1 >= .5]-1; f2[f2 >= .5] <- f2[f2 >= .5]-1
  list(f1 = sort(f1), f2 = sort(f2), Z = Z[order(f1),order(f2),drop=FALSE])
}
kth_compute <- function(Y, design, cfg) {
  methods <- c("SPG", names(cfg$alphas))
  spec <- matrix(NA_real_, design$m, length(methods), dimnames = list(NULL, methods))
  times <- setNames(numeric(length(methods)), methods)
  warns <- character(); y <- as.vector(Y); last_report <- proc.time()[3L]
  capture <- function(expr, method) withCallingHandlers(expr, warning = function(w) {
    warns <<- c(warns, paste(method, conditionMessage(w), sep = ": "))
    invokeRestart("muffleWarning")
  })
  for (s in seq.int(1L, design$m, by = cfg$chunk_size)) {
    jj <- s:min(design$m, s+cfg$chunk_size-1L)
    dd <- design; dd$freq <- design$freq[jj, , drop = FALSE]; dd$m <- length(jj)
    th <- tcrossprod(design$locations$s1, dd$freq$omega1) +
          tcrossprod(design$locations$s2, dd$freq$omega2)
    dd$Cmat <- cos(th); dd$Smat <- sin(th)
    t0 <- proc.time()[3L]
    spec[jj,"SPG"] <- spatial_pg(y-mean(y), dd)
    times["SPG"] <- times["SPG"] + proc.time()[3L]-t0
    for (method in names(cfg$alphas)) {
      t0 <- proc.time()[3L]
      spec[jj,method] <- capture(spatial_qp(y, dd, cfg$alphas[[method]]), method)
      times[method] <- times[method] + proc.time()[3L]-t0
    }
    if (proc.time()[3L]-last_report >= 20) {
      message("  frequencies: ", max(jj), "/", design$m, " (all three quantiles)")
      last_report <- proc.time()[3L]
    }
  }
  if (any(!is.finite(spec)) || any(spec < 0)) stop("Invalid spectrum; this patch was not cached.")
  list(spectra = spec, seconds_by_method = times, warnings = table(warns))
}
kth_keep <- function(design, cut) {
  with(design$freq, pmax(pmin(nu1, design$n1-nu1), pmin(nu2, design$n2-nu2)) > cut)
}
kth_freq <- function(design) {
  f <- cbind(f1 = design$freq$nu1/design$n1, f2 = design$freq$nu2/design$n2)
  f[f >= .5] <- f[f >= .5]-1; f
}
kth_pair_distance <- function(design, j) {
  f <- design$freq
  torus <- function(a,b,n) pmin(abs(a-b), n-abs(a-b))
  pmin(pmax(torus(f$nu1,f$nu1[j],design$n1),torus(f$nu2,f$nu2[j],design$n2)),
       pmax(torus(f$nu1,f$neg1[j],design$n1),torus(f$nu2,f$neg2[j],design$n2)))
}
kth_probability <- function(v, design, keep, halfwidth = 0L) {
  v[!keep] <- NA_real_
  if (halfwidth > 0L) {
    z <- periodogram_to_full_matrix(v, design)
    s <- w <- matrix(0, nrow(z), ncol(z))
    for (a in (-halfwidth):halfwidth) for (b in (-halfwidth):halfwidth) {
      u <- z[(seq_len(nrow(z))-1L+a) %% nrow(z)+1L,
             (seq_len(ncol(z))-1L+b) %% ncol(z)+1L, drop=FALSE]
      valid <- is.finite(u); u[!valid] <- 0
      s <- s+u; w <- w+valid
    }
    sm <- s/pmax(w,1); sm[w == 0] <- NA_real_
    v <- sm[cbind(design$freq$nu1+1L, design$freq$nu2+1L)]
  }
  p <- v[keep]
  if (any(!is.finite(p)) || sum(p) <= 0) return(rep(NA_real_, sum(keep)))
  p/sum(p)
}
kth_jsd <- function(p,q) {
  if (any(!is.finite(c(p,q)))) return(NA_real_)
  m <- (p+q)/2
  .5*sum(p[p>0]*log(p[p>0]/m[p>0])) + .5*sum(q[q>0]*log(q[q>0]/m[q>0]))
}
kth_degenerate <- function(v, pg, keep) {
  sum(v[keep]) <= 1e-14*max(sum(pg[keep]), .Machine$double.xmin)
}
kth_tables <- function(prep, spectra, design, cfg) {
  keep <- kth_keep(design, cfg$low_frequency_cut)
  if (sum(keep) < 10) stop("Too few frequencies remain; reduce low_frequency_cut.")
  freq <- kth_freq(design); methods <- colnames(spectra[[1]])
  metrics <- lighting <- list()
  for (i in seq_len(nrow(prep$meta))) {
    meta <- prep$meta[i, ]; V <- spectra[[i]]
    ref_id <- paste(meta$material,meta$sample,meta$scale,1L,sep="_")
    ref <- spectra[[ref_id]]
    if (is.null(ref)) stop("Front-illumination reference is missing for ", meta$image_id)
    p_pg <- kth_probability(V[,"SPG"], design, keep, cfg$jsd_halfwidth)
    for (method in methods) {
      v <- V[,method]; vr <- ref[,method]
      deg <- kth_degenerate(v,V[,"SPG"],keep)
      deg_ref <- kth_degenerate(vr,ref[,"SPG"],keep)
      j <- which(keep)[which.max(v[keep])]
      jr <- which(keep)[which.max(vr[keep])]
      p0 <- kth_probability(v,design,keep)
      p <- kth_probability(v,design,keep,cfg$jsd_halfwidth)
      pr <- kth_probability(vr,design,keep,cfg$jsd_halfwidth)
      if (deg) p[] <- p0[] <- NA_real_
      if (deg_ref) pr[] <- NA_real_
      H <- if (anyNA(p0)) NA_real_ else -sum(p0[p0>0]*log(p0[p0>0]))/log(length(p0))
      metrics[[length(metrics)+1L]] <- data.frame(
        image_id=meta$image_id, material=meta$material, sample=meta$sample,
        scale=meta$scale, illumination=meta$illumination, method=method,
        peak_f1=if(deg) NA_real_ else freq[j,1], peak_f2=if(deg) NA_real_ else freq[j,2],
        peak_power=max(v[keep]), spectrum_sum_pairs=sum(v[keep]),
        peak_pair_fraction=if(deg) NA_real_ else max(p0), normalized_entropy=H,
        jsd_to_spg=kth_jsd(p,p_pg), near_zero_spectrum=deg,
        fraction_numerically_zero=mean(v[keep] <= max(v[keep])*1e-12))
      lighting[[length(lighting)+1L]] <- data.frame(
        image_id=meta$image_id, reference_id=ref_id, material=meta$material,
        sample=meta$sample, scale=meta$scale, illumination=meta$illumination, method=method,
        jsd_to_front=kth_jsd(p,pr),
        peak_shift_bins=if(deg || deg_ref) NA_real_ else kth_pair_distance(design,jr)[j])
    }
  }
  list(metrics=do.call(rbind,metrics), lighting=do.call(rbind,lighting))
}
kth_surface <- function(v, design, keep, type, cfg, degenerate = FALSE) {
  v[!keep] <- NA_real_
  if (type == "log_normalized") {

    if (degenerate) v[] <- NA_real_ else v <- log10(v/(2*sum(v[keep])) + cfg$log_floor)
  }
  center_periodogram_matrix(v, design, normalize=FALSE)
}
kth_label <- function(method, cfg) {
  if (method == "SPG") "SPG" else sprintf("SQP (alpha = %.1f)",cfg$alphas[[method]])
}
kth_range <- function(z, zero = FALSE) {
  z <- z[is.finite(z)]
  if (!length(z)) return(c(0,1))
  r <- range(z); if (zero) r[1] <- min(0,r[1])
  if (diff(r) < 1e-14) r <- r+c(-1,1)*max(abs(r[1])*.01,1e-6)
  r
}
kth_plot_spectra <- function(results, cfg) {
  meta <- results$prep$meta; design <- results$design; specs <- results$spectra
  methods <- colnames(specs[[1]]); keep <- kth_keep(design,cfg$low_frequency_cut)
  palette <- hcl.colors(100, "Viridis")
  groups <- split(seq_len(nrow(meta)), paste(meta$material,meta$sample,meta$scale,sep="_"))
  for (material in unique(meta$material)) {
    for (type in cfg$plot_types) {
      f <- file.path(cfg$project_dir,"figures",paste0("persp3D_",material,"_",type,".pdf"))
      pdf(f,width=16,height=14,onefile=TRUE)
      tryCatch({
        for (ii in groups) {
          if (meta$material[ii[1]] != material) next
          surfaces <- lapply(ii,function(i) setNames(lapply(methods,function(m)
            kth_surface(specs[[i]][,m],design,keep,type,cfg,
                        kth_degenerate(specs[[i]][,m],specs[[i]][,"SPG"],keep))),methods))
          common_zlim <- kth_range(unlist(lapply(surfaces,function(s)lapply(s,`[[`,"Z"))),
                                    zero=type=="raw")
          par(mfrow=c(length(ii),length(methods)),oma=c(1,1,3,0))
          for (j in seq_along(ii)) for (m in methods) {
            S <- surfaces[[j]][[m]]
            title <- paste(meta$illumination[ii[j]],"|",kth_label(m,cfg))
            if (!any(is.finite(S$Z))) {
              plot.new(); title(main=title); text(.5,.5,"Near-zero spectrum\nnormalization undefined")
              next
            }

            par(mar=c(3,3,2.5,2),mgp=c(2,0.5,0))
            plot3D::persp3D(x=S$f1,y=S$f2,z=S$Z,
              xlab="Freq 1",ylab="Freq 2",
              zlab=if(type=="raw") "Periodogram" else "Log10 normalized spectrum",
              phi=cfg$phi,theta=cfg$theta,main=title,
              zlim=common_zlim,clim=common_zlim,col=palette,colkey=FALSE,
              ticktype="detailed",bty="b2",border=NA,
              cex.main=.9,cex.axis=.7,cex.lab=.8)
          }
          mtext(sprintf("%s | sample %s | scale %d | %s",material,
                        toupper(meta$sample[ii[1]]),meta$scale[ii[1]],type),outer=TRUE,font=2)
          mtext("Freq 1: row direction; Freq 2: column direction; cycles/pixel. Omitted frequencies are blank.",
                side=1,outer=TRUE,cex=.8)
        }
      },finally=dev.off())
    }
    if (cfg$make_heatmaps) {
      pdf(file.path(cfg$project_dir,"figures",paste0("heatmap_",material,".pdf")),
          width=13,height=12,onefile=TRUE)
      tryCatch({
        for (ii in groups) {
          if (meta$material[ii[1]] != material) next
          surfaces <- lapply(ii,function(i) setNames(lapply(methods,function(m)
            kth_surface(specs[[i]][,m],design,keep,"log_normalized",cfg,
                        kth_degenerate(specs[[i]][,m],specs[[i]][,"SPG"],keep))),methods))
          common <- kth_range(unlist(lapply(surfaces,function(s)lapply(s,`[[`,"Z"))))
          par(mfrow=c(length(ii),length(methods)),mar=c(3,3,2,1),mgp=c(1.6,.4,0),oma=c(0,0,3,0))
          for (j in seq_along(ii)) for (m in methods) {
            S <- surfaces[[j]][[m]]
            if (!any(is.finite(S$Z))) {
              plot.new(); title(main=paste(meta$illumination[ii[j]],"|",kth_label(m,cfg)))
              text(.5,.5,"Near-zero spectrum\nnormalization undefined")
              next
            }
            plot3D::image2D(x=S$f1,y=S$f2,z=S$Z,clim=common,col=palette,asp=1,
                  colkey=if(m==tail(methods,1L)) list(length=.65,width=.6,cex.axis=.65) else FALSE,
                  xlab="Freq 1",ylab="Freq 2",cex.axis=.7,cex.lab=.8,
                  main=paste(meta$illumination[ii[j]],"|",kth_label(m,cfg)),cex.main=.9)
            abline(h=0,v=0,lty=3,col=adjustcolor("gray50",.5)); box()
          }
          mtext(sprintf("%s | sample %s | scale %d | log10 normalized spectra; common color scale",
                        material,toupper(meta$sample[ii[1]]),meta$scale[ii[1]]),outer=TRUE,font=2)
        }
      },finally=dev.off())
    }
  }
}
kth_plot_profiles <- function(results,cfg) {
  if (!cfg$make_profiles) return(invisible(NULL))
  meta <- results$prep$meta; d <- results$design; specs <- results$spectra
  methods <- colnames(specs[[1]]); cols <- c("black","#0072B2","#009E73","#D55E00")
  keep <- kth_keep(d,cfg$low_frequency_cut)
  groups <- split(seq_len(nrow(meta)),paste(meta$material,meta$sample,meta$scale,sep="_"))
  for (material in unique(meta$material)) {
    pdf(file.path(cfg$project_dir,"figures",paste0("frequency_profiles_",material,".pdf")),
        width=11,height=11,onefile=TRUE)
    tryCatch({
      for (ii in groups) {
        if (meta$material[ii[1]] != material) next
        par(mfrow=c(length(ii),2),mar=c(3,3.7,2,1),mgp=c(1.8,.5,0),oma=c(0,0,3,0))
        for (i in ii) {
          S <- lapply(methods,function(m) {
            v <- specs[[i]][,m]; v[!keep] <- NA_real_
            if (kth_degenerate(v,specs[[i]][,"SPG"],keep)) v[] <- NA_real_
            else v <- v/(2*sum(v[keep]))
            center_periodogram_matrix(v,d,normalize=FALSE)
          })
          for (axis in 1:2) {
            x <- S[[1]][[paste0("f",axis)]]
            ys <- sapply(S,function(s) {
              if (!any(is.finite(s$Z))) return(rep(NA_real_,length(x)))
              if (axis==1) rowSums(s$Z,na.rm=TRUE) else colSums(s$Z,na.rm=TRUE)
            })
            matplot(x,ys,type="l",lty=1:4,lwd=1.5,col=cols,
                    ylim=kth_range(ys,zero=TRUE),xlab=paste("Freq",axis),ylab="Marginal spectral mass",
                    main=paste(meta$illumination[i],"| integrate over other frequency"),cex.main=.85)
            if (i==ii[1] && axis==1)
              legend("topright",legend=methods,col=cols,lty=1:4,lwd=1.5,cex=.75,bty="n")
          }
        }
        mtext(sprintf("%s | sample %s | scale %d | frequency profiles",material,
                      toupper(meta$sample[ii[1]]),meta$scale[ii[1]]),outer=TRUE,font=2)
      }
    },finally=dev.off())
  }
}
kth_plot_lighting <- function(results,cfg) {
  tab <- results$lighting; methods <- colnames(results$spectra[[1]])
  materials <- unique(tab$material); lights <- setdiff(unique(tab$illumination),"Front")
  if (!length(lights)) return(invisible(NULL))
  cols <- c("black","#0072B2","#009E73","#D55E00")
  pdf(file.path(cfg$project_dir,"figures","lighting_comparison.pdf"),width=11,height=8)
  tryCatch({
    par(mfrow=c(length(materials),2),mar=c(4,4,3,1),mgp=c(2,.5,0),oma=c(2,0,0,0))
    for (material in materials) for (metric in c("jsd_to_front","peak_shift_bins")) {
      dd <- tab[tab$material==material & tab$illumination %in% lights,]
      lim <- kth_range(dd[[metric]],zero=TRUE); lim[2] <- lim[2]+.18*diff(lim)
      plot(NA,xlim=c(.6,length(lights)+.4),ylim=lim,xaxt="n",
           xlab="Illumination",ylab=if(metric=="jsd_to_front") "JSD to front illumination" else "Peak shift (bins)",
           main=material)
      axis(1,at=seq_along(lights),labels=lights)
      for (k in seq_along(methods)) {
        d <- dd[dd$method==methods[k],]; x <- match(d$illumination,lights)+(k-2.5)*.045
        points(x,d[[metric]],col=adjustcolor(cols[k],.55),pch=15+match(d$sample,letters[1:4]),cex=.8)
        med <- vapply(lights,function(l) {
          v <- d[d$illumination==l,metric]; v <- v[is.finite(v)]
          if(length(v)) median(v) else NA_real_
        },numeric(1))
        lines(seq_along(lights)+(k-2.5)*.045,med,col=cols[k],lty=k,lwd=2)
      }
      legend("top",legend=methods,col=cols,lty=1:4,lwd=2,cex=.75,bty="n",horiz=TRUE)
    }
    mtext("Points: sample/scale combinations. Lines: medians. Descriptive comparison, not estimation error.",
          side=1,outer=TRUE,cex=.8)
  },finally=dev.off())
}
kth_plot_all <- function(results,cfg) {
  kth_dirs(cfg); kth_require("plot3D",cfg$auto_install)

  cfg$alphas <- results$config$alphas
  kth_plot_spectra(results,cfg)
  kth_plot_profiles(results,cfg)
  kth_plot_lighting(results,cfg)
  message("Figures saved in ",file.path(cfg$project_dir,"figures"))
  invisible(results)
}
kth_part2 <- function(cfg,only_plot=FALSE) {
  kth_dirs(cfg)
  output <- file.path(cfg$project_dir,"KTH_results.RData")
  if (only_plot) {
    results <- kth_load(output,"results")

    cfg$low_frequency_cut <- results$config$low_frequency_cut
    return(invisible(kth_plot_all(results,cfg)))
  }
  kth_require(c("quantreg","plot3D"),cfg$auto_install)
  prep <- kth_load(file.path(cfg$project_dir,"KTH_preprocessed.RData"),"prep")
  if (!identical(prep$version,"KTH-prep-v1")) stop("Unsupported preprocessed RData version.")
  dims <- dim(prep$patches[[1]])
  if (!all(vapply(prep$patches,function(y)identical(dim(y),dims),logical(1))))
    stop("All patches must have the same dimensions.")
  cfg$patch_size <- dims[1]; cfg$detrend <- prep$config$detrend
  if (cfg$chunk_size < 1L || cfg$chunk_size != as.integer(cfg$chunk_size) ||
      !identical(names(cfg$alphas),c("SQP01","SQP05","SQP09")) ||
      !isTRUE(all.equal(unname(cfg$alphas),c(.1,.5,.9))))
    stop("Use positive integer chunk_size and the three named quantiles 0.1/0.5/0.9.")
  design <- kth_design(dims[1],dims[2]); n <- nrow(prep$meta)
  message(sprintf("Part 2: %d patches (%d x %d), %d SQP surfaces + %d SPG surfaces; %d QR fits.",
                  n,dims[1],dims[2],3*n,n,3*n*design$m))
  spectra <- setNames(vector("list",n),prep$meta$image_id)
  timing <- warn_rows <- list()
  for (i in seq_len(n)) {
    id <- prep$meta$image_id[i]; Y <- prep$patches[[id]]
    signature <- kth_hash(list(cfg$estimator_version,cfg$alphas,Y,
                              as.character(packageVersion("quantreg")),body(spatial_qp)))
    cache <- file.path(cfg$project_dir,"cache",paste0(id,"_",signature,".rds"))
    ans <- if(file.exists(cache) && !cfg$force_recompute)
      tryCatch(readRDS(cache),error=function(e)NULL) else NULL
    reused <- !is.null(ans) && identical(ans$signature,signature) &&
      identical(dim(ans$spectra),c(design$m,4L)) && all(is.finite(ans$spectra))
    message(sprintf("[%d/%d] %s%s",i,n,id,if(reused)" [cache]" else ""))
    if (!reused) {
      ans <- kth_compute(Y,design,cfg); ans$signature <- signature
      kth_save_rds(ans,cache)
    }
    spectra[[id]] <- ans$spectra
    timing[[i]] <- data.frame(image_id=id,method=names(ans$seconds_by_method),
                              fit_seconds=as.numeric(ans$seconds_by_method),cache_reused=reused)
    if (length(ans$warnings)) warn_rows[[length(warn_rows)+1L]] <- data.frame(
      image_id=id,message=names(ans$warnings),count=as.integer(ans$warnings))
  }
  tab <- kth_tables(prep,spectra,design,cfg)
  warns <- if(length(warn_rows)) do.call(rbind,warn_rows) else
    data.frame(image_id=character(),message=character(),count=integer())
  results <- list(version="KTH-results-v1",created=as.character(Sys.time()),config=cfg,
                  prep=prep,design=design,spectra=spectra,metrics=tab$metrics,
                  lighting=tab$lighting,timing=do.call(rbind,timing),solver_warnings=warns,
                  session_info=sessionInfo())
  save(results,file=output,compress="xz")
  kth_csv(results$metrics,"spectral_metrics.csv",cfg)
  kth_csv(results$lighting,"lighting_changes.csv",cfg)
  kth_csv(results$timing,"computation_time.csv",cfg)
  kth_csv(warns,"solver_warnings.csv",cfg)
  writeLines(capture.output(sessionInfo()),file.path(cfg$project_dir,"tables","sessionInfo.txt"))
  if (nrow(warns)) message("Solver warnings were recorded in tables/solver_warnings.csv.")
  if (any(results$metrics$near_zero_spectrum))
    message("Near-zero spectra detected; normalized summaries are marked NA. See spectral_metrics.csv.")
  kth_plot_all(results,cfg)
  message("Part 2 complete. Saved KTH_results.RData; subsequent plotting needs this file only.")
  invisible(results)
}

if (isTRUE(getOption("kth.sqp.autorun", TRUE))) {
  if (!length(RUN_PARTS) || !all(RUN_PARTS %in% c(1L,2L)))
    stop("RUN_PARTS must be 1L, 2L, or c(1L,2L).")
  if (2L %in% RUN_PARTS) kth_part2(cfg,only_plot=ONLY_PLOT)
}
