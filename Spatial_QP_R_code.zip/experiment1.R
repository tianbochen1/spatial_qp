ALPHA <- c(0.6, 0.8)
B <- c(0, 0.2, 0.4, 0.6)
LATTICES <- rbind(c(24L, 24L), c(48L, 48L))
SIGNIFICANCE_LEVELS <- c(0.10, 0.05, 0.01)
NREP <- 2000L
SEED <- 1L
PHASE <- pi / 4
TARGET_CYCLES <- c(1/8, 1/8)  
N_WORKERS <- 8L              
BATCH_SIZE <- 8L
OUTPUT_DIR <- file.path(getwd(), "experiment1_results", paste0("R", NREP))

make_design_checked <- function(n1,n2,target_index) {
  dims <- c(n1,n2)
  if(any(!is.finite(dims)) || any(dims<3) || any(dims!=round(dims)))
    stop("Lattice sizes must be integers >=3.")
  n1 <- as.integer(n1); n2 <- as.integer(n2)
  if(length(target_index)!=2L || any(!is.finite(target_index)) ||
     any(target_index!=round(target_index)) || any(target_index<0) ||
     any(target_index>=dims)) stop("Invalid target Fourier indices.")
  sites <- expand.grid(s1=seq_len(n1),s2=seq_len(n2))
  f <- expand.grid(nu1=0:(n1-1L),nu2=0:(n2-1L))
  f$neg1 <- (-f$nu1)%%n1; f$neg2 <- (-f$nu2)%%n2
  f <- f[f$nu1*n2+f$nu2 < f$neg1*n2+f$neg2,,drop=FALSE]
  rownames(f) <- NULL
  theta <- tcrossprod(sites$s1,2*pi*f$nu1/n1)+
    tcrossprod(sites$s2,2*pi*f$nu2/n2)
  target <- which((f$nu1==target_index[1]&f$nu2==target_index[2]) |
                  (f$neg1==target_index[1]&f$neg2==target_index[2]))
  if(length(target)!=1L) stop("Target must be nonzero and non-self-conjugate.")
  list(n1=n1,n2=n2,N=n1*n2,m=nrow(f),locations=sites,freq=f,
       Cmat=cos(theta),Smat=sin(theta),target_col=target,
       target_index=as.integer(target_index),target_cycles=target_index/dims)
}

spg_checked <- function(y,d) {
  if(length(y)!=d$N || any(!is.finite(y))) stop("Invalid observations.")

  z <- fft(matrix(y,nrow=d$n1,ncol=d$n2))
  Mod(z[cbind(d$freq$nu1+1L,d$freq$nu2+1L)])^2/d$N
}

sqp_checked <- function(y,d,alpha,record_issue=function(...)NULL) {
  if(length(y)!=d$N || any(!is.finite(y))) stop("Invalid observations.")
  if(length(alpha)!=1L || !is.finite(alpha) || alpha<=0 || alpha>=1)
    stop("alpha must lie strictly between 0 and 1.")
  ans <- numeric(d$m)
  for(j in seq_len(d$m)) {
    X <- cbind(1,d$Cmat[,j],d$Smat[,j])
    beta <- withCallingHandlers(tryCatch(
      quantreg::rq.fit.fnb(x=X,y=y,tau=alpha)$coefficients,
      error=function(e) {
        record_issue(j,"fnb_error",conditionMessage(e)); rep(NA_real_,3L)
      }),warning=function(w) {
        record_issue(j,"fnb_warning",conditionMessage(w))
        invokeRestart("muffleWarning")
      })
    if(length(beta)!=3L || any(!is.finite(beta))) {
      record_issue(j,"br_fallback","Missing or nonfinite FNB coefficients")
      beta <- withCallingHandlers(
        quantreg::rq.fit.br(x=X,y=y,tau=alpha)$coefficients,
        warning=function(w) {
          record_issue(j,"br_warning",conditionMessage(w))
          invokeRestart("muffleWarning")
        })
    }
    if(length(beta)!=3L || any(!is.finite(beta)))
      stop("Both QR solvers failed at frequency ",j,"; no ordinate was dropped.")
    ans[j] <- d$N*sum(beta[2:3]^2)/4
  }
  ans
}

fisher_g_checked <- function(x,m) {

  if(length(x)!=m || any(!is.finite(x)) || any(x<0) || max(x)<=0)
    stop("Expected m finite, nonnegative reduced ordinates with positive sum.")
  z <- x/max(x)
  1/sum(z)
}

fisher_critical_checked <- function(m,levels) {
  if(length(m)!=1L || m<2L || m!=round(m)) stop("Invalid m.")
  if(any(!is.finite(levels)) || any(levels<=0 | levels>0.1))
    stop("This upper-tail routine supports significance levels in (0,0.1].")
  tail <- function(g) {
    if(g<=1/m) return(1)
    if(g>=1) return(0)
    j <- seq_len(min(m,floor(1/g))); j <- j[1-j*g>0]
    sum((-1)^(j-1)*exp(lchoose(m,j)+(m-1)*log1p(-j*g)))
  }

  lo <- max(1/m,log(m)/m)
  vapply(levels,function(level) {
    hi <- min(1,(log(m)-log(level)+3)/m)
    if(tail(lo)<=level || tail(hi)>=level) stop("Critical-value bracket failed.")
    uniroot(function(g)tail(g)-level,c(lo,hi),tol=1e-12)$root
  },numeric(1))
}

checkpoint_checked <- function(x,path) {
  tmp <- paste0(path,".tmp")
  saveRDS(x,tmp)
  if(!file.copy(tmp,path,overwrite=TRUE)) stop("Could not save checkpoint: ",path)
  unlink(tmp)
}

empty_solver_log <- function() {
  data.frame(n1=integer(),n2=integer(),rep=integer(),b=numeric(),
    alpha=numeric(),frequency_index=integer(),kind=character(),message=character())
}

experiment1_one_rep <- function(r,context) {
  d <- context$design; cfg <- context$config
  RNGkind("Mersenne-Twister","Inversion","Rejection")
  set.seed(cfg$seed+r)

  invisible(rnorm(d$N))
  epsilon <- rnorm(d$N)
  g <- numeric(nrow(context$row_info)); issues <- list()
  nr_methods <- 1L+length(cfg$alpha)
  for(ib in seq_along(cfg$b)) {
    b <- cfg$b[ib]
    y <- context$sigma[,ib]*epsilon
    rows <- (ib-1L)*nr_methods+seq_len(nr_methods)
    g[rows[1L]] <- fisher_g_checked(spg_checked(y,d),d$m)
    for(ia in seq_along(cfg$alpha)) {
      record <- function(j,kind,message) {
        issues[[length(issues)+1L]] <<- data.frame(
          n1=d$n1,n2=d$n2,rep=r,b=b,alpha=cfg$alpha[ia],
          frequency_index=j,kind=kind,message=message)
      }
      q <- sqp_checked(y,d,cfg$alpha[ia],record_issue=record)
      g[rows[ia+1L]] <- fisher_g_checked(q,d$m)
    }
  }
  list(g=g,issues=if(length(issues))do.call(rbind,issues) else empty_solver_log())
}

experiment1_worker <- function(r) {
  experiment1_one_rep(r,get(".experiment1_context",envir=.GlobalEnv))
}

experiment1_matrix <- function(states,row_info,column_info) {
  nr <- nrow(row_info); nc <- nrow(column_info)
  dn <- list(row_info$label,column_info$label)
  res <- matrix(NA_real_,nr,nc,dimnames=dn)
  counts <- matrix(NA_integer_,nr,nc,dimnames=dn)
  completed <- matrix(0L,nr,nc,dimnames=dn)
  for(i in seq_along(states)) {
    st <- states[[i]]
    if(is.null(st) || st$done==0L) next
    columns <- which(column_info$lattice_id==i)
    g <- st$g[seq_len(st$done),,drop=FALSE]
    for(j in seq_along(columns)) {
      k <- columns[j]
      counts[,k] <- colSums(g>st$critical_values[j])
      completed[,k] <- st$done
      res[,k] <- counts[,k]/st$done
    }
  }
  list(res=res,rejection_counts=counts,completed_nrep=completed,
       res_mcse=sqrt(res*(1-res)/completed))
}

run_experiment1 <- function(
    alpha=ALPHA,b_values=B,lattices=LATTICES,levels=SIGNIFICANCE_LEVELS,
    nrep=NREP,seed=SEED,phase=PHASE,target_cycles=TARGET_CYCLES,
    n_workers=N_WORKERS,batch_size=BATCH_SIZE,output_dir=OUTPUT_DIR) {
  if(!requireNamespace("quantreg",quietly=TRUE))
    stop("Install the only required package first: install.packages('quantreg')")
  is_integer_scalar <- function(x) length(x)==1L && is.finite(x) && x==round(x)
  if(!is_integer_scalar(nrep) || nrep<1L ||
     !is_integer_scalar(seed) || seed<0 || seed+nrep>.Machine$integer.max ||
     !is_integer_scalar(n_workers) || n_workers<1L ||
     !is_integer_scalar(batch_size) || batch_size<1L) stop("Invalid run settings.")
  stopifnot(length(alpha)>0L,all(is.finite(alpha)),all(alpha>0 & alpha<1),
    !anyDuplicated(alpha),length(b_values)>0L,all(is.finite(b_values)),
    all(b_values>=0 & b_values<1),!anyDuplicated(b_values),
    is.matrix(lattices),ncol(lattices)==2L,nrow(lattices)>0L,
    all(is.finite(lattices)),all(lattices==round(lattices)),all(lattices>=3),
    !anyDuplicated(data.frame(lattices)),
    length(levels)>0L,all(is.finite(levels)),all(levels>0 & levels<=.1),
    !anyDuplicated(levels),length(phase)==1L,is.finite(phase),
    length(target_cycles)==2L,all(is.finite(target_cycles)),
    all(target_cycles>=0 & target_cycles<1))
  raw_indices <- sweep(lattices,2L,target_cycles,"*")
  if(any(abs(raw_indices-round(raw_indices))>1e-10))
    stop("The target frequency is not on every lattice's Fourier grid.")
  target_indices <- round(raw_indices)
  cfg <- list(algorithm_version="experiment1-table1-v1",
    alpha=as.numeric(alpha),b=as.numeric(b_values),lattices=lattices,
    levels=as.numeric(levels),nrep=as.integer(nrep),seed=as.integer(seed),
    phase=phase,target_cycles=target_cycles,target_indices=target_indices,
    RNGkind=c("Mersenne-Twister","Inversion","Rejection"),
    discard_first_normal_batch=TRUE,
    R_version=R.version.string,
    quantreg_version=as.character(utils::packageVersion("quantreg")))

  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  config_path <- file.path(output_dir,"configuration.rds")
  if(file.exists(config_path) && !identical(readRDS(config_path),cfg))
    stop("OUTPUT_DIR contains different scientific settings. Choose a new directory.")
  checkpoint_checked(cfg,config_path)
  capture.output(sessionInfo(),file=file.path(output_dir,"sessionInfo.txt"))

  methods <- c("SPG",paste0("SQP(",alpha,")"))
  row_info <- do.call(rbind,lapply(b_values,function(b) {
    data.frame(b=b,method=methods,alpha=c(NA_real_,alpha),
      label=paste0("b=",format(b,trim=TRUE)," | ",methods))
  }))
  rownames(row_info) <- NULL
  column_info <- do.call(rbind,lapply(seq_len(nrow(lattices)),function(i) {
    data.frame(lattice_id=i,n1=lattices[i,1L],n2=lattices[i,2L],
      significance_level=levels,
      label=paste0(lattices[i,1L],"x",lattices[i,2L]," | ",
        formatC(levels,format="f",digits=2L)))
  }))
  states <- vector("list",nrow(lattices)); all_issues <- list()
  checkpoint_dir <- file.path(output_dir,"checkpoints")
  dir.create(checkpoint_dir,showWarnings=FALSE)

  cl <- NULL
  if(n_workers>1L) {
    cl <- parallel::makePSOCKcluster(as.integer(min(n_workers,nrep,batch_size)))
    on.exit(parallel::stopCluster(cl),add=TRUE)
    worker_versions <- parallel::clusterCall(cl,function(paths) {
      .libPaths(paths)
      if(!requireNamespace("quantreg",quietly=TRUE)) stop("quantreg is missing on a worker.")
      as.character(utils::packageVersion("quantreg"))
    },.libPaths())
    if(any(unlist(worker_versions)!=cfg$quantreg_version))
      stop("quantreg versions differ between the master and workers.")
    parallel::clusterExport(cl,c("spg_checked","sqp_checked","fisher_g_checked",
      "empty_solver_log","experiment1_one_rep","experiment1_worker"),
      envir=environment(run_experiment1))
  }
  cat("Table 1:",nrow(row_info),"rows x",nrow(column_info),"columns\n")
  cat("Replications:",nrep,"; alpha:",alpha,"; b:",b_values,"\n")
  cat("Output directory:",normalizePath(output_dir,winslash="/"),"\n")

  for(i in seq_len(nrow(lattices))) {
    d <- make_design_checked(lattices[i,1L],lattices[i,2L],target_indices[i,])
    critical <- fisher_critical_checked(d$m,levels)

    theta <- 2*pi*d$target_index[1L]*d$locations$s1/d$n1+
             2*pi*d$target_index[2L]*d$locations$s2/d$n2
    sigma <- vapply(b_values,function(b)
      (1+b*cos(theta+phase))/sqrt(1+b^2/2),numeric(d$N))
    context <- list(design=d,config=cfg,sigma=sigma,row_info=row_info)
    path <- file.path(checkpoint_dir,paste0("n",d$n1,"x",d$n2,".rds"))
    if(file.exists(path)) {
      st <- readRDS(path)
      if(!identical(st$config,cfg) || !identical(st$lattice_id,i) ||
         !identical(dim(st$g),c(as.integer(nrep),nrow(row_info))) ||
         length(st$done)!=1L || st$done<0L || st$done>nrep ||
         st$done!=round(st$done)) stop("Incompatible checkpoint: ",path)
      if(st$done>0L && any(!is.finite(st$g[seq_len(st$done),,drop=FALSE])))
        stop("Checkpoint contains incomplete replications: ",path)
    } else st <- list(config=cfg,lattice_id=i,done=0L,
      g=matrix(NA_real_,nrep,nrow(row_info),dimnames=list(NULL,row_info$label)),
      critical_values=critical,issues=empty_solver_log())
    if(!is.null(cl) && st$done<nrep) {
      invisible(parallel::clusterCall(cl,function(x) {
        assign(".experiment1_context",x,envir=.GlobalEnv);NULL
      },context))
    }
    cat("\nLattice",d$n1,"x",d$n2,"; target indices",d$target_index,
        "; retained frequencies",d$m,"; completed",st$done,"/",nrep,"\n")
    while(st$done<nrep) {
      ids <- seq.int(st$done+1L,min(st$done+batch_size,nrep))
      values <- if(is.null(cl)) {
        lapply(ids,experiment1_one_rep,context=context)
      } else parallel::parLapplyLB(cl,ids,experiment1_worker)
      new_g <- do.call(rbind,lapply(values,function(x)x$g))
      if(any(!is.finite(new_g))) stop("Nonfinite g statistic; batch was not saved.")
      st$g[ids,] <- new_g
      new_issues <- do.call(rbind,lapply(values,function(x)x$issues))
      if(nrow(new_issues)) st$issues <- rbind(st$issues,new_issues)
      st$done <- max(ids)
      checkpoint_checked(st,path)
      states[[i]] <- st
      partial <- experiment1_matrix(states,row_info,column_info)
      write.csv(partial$res,file.path(output_dir,"res_partial.csv"))
      cat(format(Sys.time(),"%H:%M:%S"),":",d$n1,"x",d$n2,
          " completed ",st$done,"/",nrep,"\n",sep="")
      flush.console()
    }
    states[[i]] <- st
    all_issues[[i]] <- st$issues
  }
  result <- experiment1_matrix(states,row_info,column_info)
  stopifnot(all(is.finite(result$res)),all(result$completed_nrep==nrep))
  solver_diagnostics <- do.call(rbind,all_issues)
  res <- result$res
  res_mcse <- result$res_mcse
  rejection_counts <- result$rejection_counts
  completed_nrep <- result$completed_nrep
  settings <- cfg
  g_statistics <- lapply(states,function(st)st$g)
  critical_values <- lapply(states,function(st)st$critical_values)
  names(g_statistics) <- names(critical_values) <-
    apply(lattices,1L,paste,collapse="x")
  write.csv(res,file.path(output_dir,"res.csv"))
  write.csv(res_mcse,file.path(output_dir,"res_mcse.csv"))
  write.csv(row_info,file.path(output_dir,"row_info.csv"),row.names=FALSE)
  write.csv(column_info,file.path(output_dir,"column_info.csv"),row.names=FALSE)
  write.csv(solver_diagnostics,file.path(output_dir,"solver_diagnostics.csv"),row.names=FALSE)
  save(res,res_mcse,rejection_counts,completed_nrep,row_info,column_info,
       settings,g_statistics,critical_values,solver_diagnostics,
       file=file.path(output_dir,"experiment1_results.RData"))
  cat("\nComplete Table 1: empirical rejection rates\n")
  print(round(res,4L))
  if(nrow(solver_diagnostics))
    warning("Solver diagnostics were recorded. Inspect solver_diagnostics.csv before reporting the table.")
  invisible(c(result,list(row_info=row_info,column_info=column_info,
    settings=cfg,solver_diagnostics=solver_diagnostics)))
}

if(!isTRUE(getOption("experiment1.functions_only",FALSE))) {
  experiment1_results <- run_experiment1()
  res <- experiment1_results$res                 
  res_mcse <- experiment1_results$res_mcse
  rejection_counts <- experiment1_results$rejection_counts

}
