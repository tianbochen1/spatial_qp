NREP <- 1000L
LATTICES <- rbind(c(24L,24L),c(48L,48L))
colnames(LATTICES) <- c("n1","n2")
EPSILON <- c(1,2,3)/24
KAPPA <- c(6,9,12)
ALPHA <- c(0.5,0.6,0.7,0.8)
SEED <- 20260904L
N_WORKERS <- 8L
BATCH_SIZE <- 8L
OUTPUT_DIR <- file.path(getwd(),"experiment2_results",paste0("R",NREP))

make_spatial_design <- function(n1, n2, target_index = NULL) {
  dims <- c(n1,n2)
  if(length(dims)!=2L || any(!is.finite(dims)) || any(dims<3) ||
     any(dims!=round(dims))) stop("Lattice sizes must be integers >=3.")
  n1 <- as.integer(n1)
  n2 <- as.integer(n2)
  N <- n1 * n2

  locations <- expand.grid(
    s1 = seq_len(n1),
    s2 = seq_len(n2)
  )

  full_grid <- expand.grid(
    nu1 = 0:(n1 - 1L),
    nu2 = 0:(n2 - 1L)
  )

  full_grid$neg1 <- (-full_grid$nu1) %% n1
  full_grid$neg2 <- (-full_grid$nu2) %% n2
  full_grid$self_conjugate <-
    full_grid$nu1 == full_grid$neg1 &
    full_grid$nu2 == full_grid$neg2

  key <- full_grid$nu1 * n2 + full_grid$nu2
  neg_key <- full_grid$neg1 * n2 + full_grid$neg2
  keep <- !full_grid$self_conjugate & key < neg_key

  freq <- full_grid[keep, c("nu1", "nu2", "neg1", "neg2")]
  rownames(freq) <- NULL
  freq$omega1 <- 2 * pi * freq$nu1 / n1
  freq$omega2 <- 2 * pi * freq$nu2 / n2

  theta <-
    tcrossprod(locations$s1, freq$omega1) +
    tcrossprod(locations$s2, freq$omega2)

  Cmat <- cos(theta)
  Smat <- sin(theta)

  target_col <- NULL
  target_frequency <- NULL

  if (!is.null(target_index)) {
    target_index <- as.integer(target_index)
    target_col <- which(
      (freq$nu1 == target_index[1L] &
         freq$nu2 == target_index[2L]) |
      (freq$neg1 == target_index[1L] &
         freq$neg2 == target_index[2L])
    )

    if (length(target_col) != 1L) {
      stop("The target frequency must be nonzero and non-self-conjugate.")
    }

    target_frequency <- c(
      target_index[1L] / n1,
      target_index[2L] / n2
    )
  }

  list(
    n1 = n1,
    n2 = n2,
    N = N,
    locations = locations,
    full_grid = full_grid,
    freq = freq,
    Cmat = Cmat,
    Smat = Smat,
    m = nrow(freq),
    target_index = target_index,
    target_col = target_col,
    target_frequency = target_frequency
  )
}

spg_checked <- function(y,d) {
  if(length(y)!=d$N || any(!is.finite(y))) stop("Invalid observations.")

  z <- fft(matrix(y,nrow=d$n1,ncol=d$n2))
  Mod(z[cbind(d$freq$nu1+1L,d$freq$nu2+1L)])^2/d$N
}

sqp_checked <- function(y,d,alpha,record_issue=function(...)NULL) {
  if(length(y)!=d$N || any(!is.finite(y))) stop("Invalid observations.")
  if(length(alpha)!=1L || !is.finite(alpha) || alpha<=0 || alpha>=1)
    stop("alpha must lie strictly between 0 and 1.")
  ans <- numeric(d$m)
  for(j in seq_len(d$m)) {
    X <- cbind(1,d$Cmat[,j],d$Smat[,j])
    beta <- withCallingHandlers(tryCatch(
      quantreg::rq.fit.fnb(x=X,y=y,tau=alpha)$coefficients,
      error=function(e) {
        record_issue(j,"fnb_error",conditionMessage(e)); rep(NA_real_,3L)
      }),warning=function(w) {
        record_issue(j,"fnb_warning",conditionMessage(w))
        invokeRestart("muffleWarning")
      })
    if(length(beta)!=3L || any(!is.finite(beta))) {
      record_issue(j,"br_fallback","Missing or nonfinite FNB coefficients")
      beta <- withCallingHandlers(
        quantreg::rq.fit.br(x=X,y=y,tau=alpha)$coefficients,
        warning=function(w) {
          record_issue(j,"br_warning",conditionMessage(w))
          invokeRestart("muffleWarning")
        })
    }
    if(length(beta)!=3L || any(!is.finite(beta)))
      stop("Both QR solvers failed at frequency ",j,"; no ordinate was dropped.")
    ans[j] <- d$N*sum(beta[2:3]^2)/4
  }
  ans
}

smooth_hotspot_range <- function(n1, n2, epsilon) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon <= 0 || epsilon >= 1) {
    stop("epsilon must be a single number strictly between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  K <- round(epsilon * N)

  if (!is.finite(N) || K <= 1 || K >= N) {
    stop("A finite positive range requires 1 < round(epsilon * N) < N.")
  }

  u1 <- seq_len(n1) - 1
  u2 <- seq_len(n2) - 1
  d1 <- pmin(u1, n1 - u1)
  d2 <- pmin(u2, n2 - u2)

  objective <- function(r) {
    if (r == 0) return(1 - K)

    sum(exp(-(d1 / r)^2)) *
      sum(exp(-(d2 / r)^2)) - K
  }

  upper <- max(n1, n2)
  while (objective(upper) < 0) {
    upper <- 2 * upper
  }

  stats::uniroot(
    f = objective,
    interval = c(0, upper),
    tol = 1e-10,
    check.conv = TRUE
  )$root
}

make_scattered_contamination <- function(n1, n2, epsilon,
                                         ordering = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon < 0 || epsilon > 1) {
    stop("epsilon must be a single number between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  if (!is.finite(N)) stop("The lattice size must be finite.")
  K <- round(epsilon * N)

  if (is.null(ordering)) {
    ordering <- sample.int(N)
  } else if (!is.numeric(ordering) || is.complex(ordering) ||
             length(ordering) != N || any(!is.finite(ordering)) ||
             any(ordering != floor(ordering)) ||
             any(ordering < 1 | ordering > N) ||
             anyDuplicated(ordering) > 0L) {
    stop("ordering must be a permutation of seq_len(n1 * n2).")
  }

  index <- ordering[seq_len(K)]

  W <- matrix(0, nrow = n1, ncol = n2)
  W[index] <- 1

  list(
    weight = W,
    index = index,
    K = K,
    epsilon_actual = K / N
  )
}

make_strip_contamination <- function(n1, n2, epsilon,
                                     orientation = NULL,
                                     start = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon < 0 || epsilon > 1) {
    stop("epsilon must be a single number between 0 and 1.")
  }

  if (is.null(orientation)) {
    orientation <- sample(c("horizontal", "vertical"), size = 1L)
  }

  if (!is.character(orientation) || length(orientation) != 1L ||
      is.na(orientation) ||
      !orientation %in% c("horizontal", "vertical")) {
    stop("orientation must be 'horizontal' or 'vertical'.")
  }

  axis_length <- if (orientation == "horizontal") n1 else n2

  if (is.null(start)) {
    start <- sample.int(axis_length, size = 1L)
  }

  if (!valid_size(start) || start > axis_length) {
    stop("start must be an integer within the selected axis.")
  }

  width <- if (epsilon == 0) {
    0
  } else {
    max(1, round(epsilon * axis_length))
  }

  strip_index <- ((start - 1 + seq_len(width) - 1) %% axis_length) + 1

  W <- matrix(0, nrow = n1, ncol = n2)

  if (orientation == "horizontal") {
    W[strip_index, ] <- 1
  } else {
    W[, strip_index] <- 1
  }

  list(
    weight = W,
    orientation = orientation,
    start = start,
    width = width,
    strip_index = strip_index,
    K = sum(W),
    epsilon_actual = width / axis_length
  )
}

make_smooth_hotspot_contamination <- function(n1, n2, epsilon,
                                              center = NULL,
                                              range = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon <= 0 || epsilon >= 1) {
    stop("epsilon must be a single number strictly between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  K <- round(epsilon * N)

  if (!is.finite(N) || K <= 1 || K >= N) {
    stop("A finite positive range requires 1 < round(epsilon * N) < N.")
  }

  if (is.null(center)) {
    center <- c(sample.int(n1, 1L), sample.int(n2, 1L))
  }

  if (!is.numeric(center) || is.complex(center) ||
      length(center) != 2L || any(!is.finite(center)) ||
      any(center != floor(center)) ||
      any(center < 1) || any(center > c(n1, n2))) {
    stop("center must contain valid integer row and column indices.")
  }

  if (is.null(range)) {
    range <- smooth_hotspot_range(
      n1 = n1, n2 = n2, epsilon = epsilon
    )
  }

  if (!is.numeric(range) || is.complex(range) ||
      length(range) != 1L || !is.finite(range) || range <= 0) {
    stop("range must be a single finite positive number.")
  }

  d1 <- abs(seq_len(n1) - center[1L])
  d2 <- abs(seq_len(n2) - center[2L])
  d1 <- pmin(d1, n1 - d1)
  d2 <- pmin(d2, n2 - d2)

  W <- exp(-outer((d1 / range)^2, (d2 / range)^2, "+") / 2)

  effective_size <- sum(W^2)

  if (abs(effective_size - K) > 1e-7 * max(1, K)) {
    stop(
      "range is inconsistent with epsilon; recompute it with smooth_hotspot_range()."
    )
  }

  list(
    weight = W,
    center = center,
    range = range,
    K = K,
    effective_size = effective_size,
    epsilon_actual = effective_size / N
  )
}

epsilon_labels <- function(x) {
  vapply(x,function(e) {
    p <- round(24*e)
    if(abs(24*e-p)<1e-10) paste0(p,"/24") else format(e,digits=10,trim=TRUE)
  },character(1L))
}

periodogram_error_components <- function(contaminated,uncontaminated,m=length(uncontaminated)) {
  if(length(contaminated)!=m || length(uncontaminated)!=m || m<1L ||
     any(!is.finite(contaminated)) || any(!is.finite(uncontaminated)) ||
     any(contaminated<0) || any(uncontaminated<0))
    stop("Expected matching finite nonnegative ordinates on the complete retained grid.")
  ans <- c(SSE=sum((contaminated-uncontaminated)^2),
           BASE=sum(uncontaminated^2),COUNT=m)
  if(any(!is.finite(ans)) || ans["BASE"]<=0)
    stop("Nonfinite squared error or nonpositive reference denominator.")
  ans
}

experiment2_empty_log <- function() {
  data.frame(n1=integer(),n2=integer(),rep=integer(),type=integer(),
    epsilon=numeric(),kappa=numeric(),alpha=numeric(),frequency=integer(),
    kind=character(),message=character())
}

experiment2_one_rep <- function(r,context) {
  cfg <- context$config; d <- context$design; g <- context$lattice_id
  RNGkind("Mersenne-Twister","Inversion","Rejection")
  set.seed(cfg$seed+100000L*g+r)
  issues <- list()
  spectra <- function(y,type=0L,epsilon=0,kappa=0) {
    z <- matrix(NA_real_,d$m,length(cfg$alpha)+1L)
    z[,1L] <- spg_checked(y,d)
    for(a in seq_along(cfg$alpha)) {
      record <- function(j,kind,message) {
        issues[[length(issues)+1L]] <<- data.frame(n1=d$n1,n2=d$n2,rep=r,
          type=type,epsilon=epsilon,kappa=kappa,alpha=cfg$alpha[a],
          frequency=j,kind=kind,message=message)
      }
      z[,a+1L] <- sqp_checked(y,d,cfg$alpha[a],record)
    }
    if(any(!is.finite(z))) stop("Nonfinite spectrum; no frequency may be dropped.")
    z
  }
  y0 <- rnorm(d$N)
  clean <- spectra(y0)
  base <- colSums(clean^2)
  if(any(!is.finite(base)) || any(base<=0)) stop("Invalid clean spectral denominator.")

  ordering <- sample.int(d$N)
  orientation <- sample(c("horizontal","vertical"),size=1L)
  start <- sample.int(if(orientation=="horizontal") d$n1 else d$n2,size=1L)
  center <- c(sample.int(d$n1,size=1L),sample.int(d$n2,size=1L))
  sse <- array(0,dim=c(length(cfg$epsilon),length(cfg$kappa),
                       length(cfg$alpha)+1L,3L))
  qc <- list()
  for(e in seq_along(cfg$epsilon)) {
    epsilon <- cfg$epsilon[e]
    objects <- list(
      make_scattered_contamination(d$n1,d$n2,epsilon,ordering=ordering),
      make_strip_contamination(d$n1,d$n2,epsilon,orientation=orientation,start=start),
      make_smooth_hotspot_contamination(d$n1,d$n2,epsilon,
        center=center,range=context$smooth_ranges[e]))
    target_K <- round(epsilon*d$N)
    for(type in 1:3) {
      W <- objects[[type]]$weight
      energy <- sum(W^2)
      if(any(!is.finite(W)) || any(W<0 | W>1) ||
         abs(energy-target_K)>1e-7*max(1,target_K))
        stop("Contamination energy does not match epsilon*N.")
      qc[[length(qc)+1L]] <- data.frame(n1=d$n1,n2=d$n2,rep=r,type=type,
        epsilon=epsilon,target_K=target_K,squared_weight_sum=energy,
        centered_squared_weight_sum=sum((W-mean(W))^2),
        nonzero_sites=sum(W>0),orientation=if(type==2L)orientation else NA_character_,
        strip_width=if(type==2L)objects[[type]]$width else NA_real_,
        center1=if(type==3L)center[1L] else NA_real_,
        center2=if(type==3L)center[2L] else NA_real_)
    }
    for(k in seq_along(cfg$kappa)) for(type in 1:3) {
      y <- y0+cfg$kappa[k]*as.vector(objects[[type]]$weight)
      contaminated <- spectra(y,type,epsilon,cfg$kappa[k])
      for(method in seq_len(ncol(clean))) {
        err <- periodogram_error_components(contaminated[,method],clean[,method],d$m)
        sse[e,k,method,type] <- err["SSE"]
      }
    }
  }
  list(SSE=sse,BASE=base,COUNT=d$m,QC=do.call(rbind,qc),
       issues=if(length(issues))do.call(rbind,issues) else experiment2_empty_log())
}

experiment2_worker <- function(r) {
  context <- get(".experiment2_context",envir=.GlobalEnv)
  tryCatch(experiment2_one_rep(r,context),error=function(e)
    stop("Lattice ",context$design$n1,"x",context$design$n2,
         ", replication ",r,": ",conditionMessage(e),call.=FALSE))
}

save_checkpoint2 <- function(x,path) {
  tmp <- paste0(path,".tmp")
  saveRDS(x,tmp)
  if(!file.copy(tmp,path,overwrite=TRUE)) stop("Could not save ",path)
  unlink(tmp)
}

average_sqp_nrmse <- function(x) {
  if(length(dim(x))!=4L) stop("Expected a 4-D array.")
  labels <- dimnames(x)[[4L]]
  ix <- which(startsWith(labels,"SQP("))
  if(length(ix)==0L || !"SPG" %in% labels) stop("Missing SPG or SQP results.")
  out <- array(NA_real_,c(dim(x)[1:3],2L),
    dimnames=c(dimnames(x)[1:3],list(Method=c("SPG","SQP(mean)"))))
  out[,,,1L] <- x[,,,match("SPG",labels),drop=FALSE]
  out[,,,2L] <- apply(x[,,,ix,drop=FALSE],1:3,mean)
  out
}

contamination_array_to_table <- function(x,cfg) {
  rows <- list()
  for(g in seq_len(dim(x)[1L])) for(e in seq_len(dim(x)[2L]))
    for(k in seq_len(dim(x)[3L])) {
      z <- data.frame(Lattice=dimnames(x)[[1L]][g],Epsilon=cfg$epsilon[e],
                      Kappa=cfg$kappa[k],check.names=FALSE)
      for(m in seq_len(dim(x)[4L])) z[[dimnames(x)[[4L]][m]]] <- x[g,e,k,m]
      rows[[length(rows)+1L]] <- z
    }
  do.call(rbind,rows)
}

experiment2_summarize <- function(states,cfg) {
  lattice_names <- apply(cfg$lattices,1L,paste,collapse="x")
  methods <- c("SPG",paste0("SQP(",cfg$alpha,")"))
  dn <- list(Lattice=lattice_names,Epsilon=epsilon_labels(cfg$epsilon),
             Kappa=as.character(cfg$kappa),Method=methods)
  dims <- unname(lengths(dn))
  out <- list(); pooled_base <- array(NA_real_,dims,dimnames=dn)
  counts <- array(NA_real_,dims,dimnames=dn)
  done <- setNames(integer(length(states)),lattice_names)
  for(g in seq_along(states)) {
    st <- states[[g]]
    if(is.null(st) || st$done==0L) next
    done[g] <- st$done
    for(m in seq_along(methods)) pooled_base[g,,,m] <- st$BASE[m]
    counts[g,,,] <- st$COUNT
  }
  all_tables <- all_full <- list()
  for(type in 1:3) {
    sse <- array(NA_real_,dims,dimnames=dn)
    for(g in seq_along(states)) {
      st <- states[[g]]
      if(!is.null(st) && st$done>0L) sse[g,,,] <- st$SSE[,,,type,drop=FALSE]
    }
    individual <- sqrt(sse/pooled_base)
    avg <- average_sqp_nrmse(individual)
    tab <- contamination_array_to_table(avg,cfg)
    full <- contamination_array_to_table(individual,cfg)
    labels <- paste0("Type",type," | ",tab$Lattice," | epsilon=",
      epsilon_labels(tab$Epsilon)," | kappa=",tab$Kappa)
    values <- as.matrix(tab[,c("SPG","SQP(mean)"),drop=FALSE]);rownames(values)<-labels
    indiv <- as.matrix(full[,methods,drop=FALSE]);rownames(indiv)<-labels
    out[[paste0("SSE",type)]] <- sse
    out[[paste0("BASE",type)]] <- pooled_base
    out[[paste0("COUNT",type)]] <- counts
    out[[paste0("rmse",type)]] <- sqrt(sse/counts)
    out[[paste0("nrmse",type,"_by_quantile")]] <- individual
    out[[paste0("res",type)]] <- avg
    out[[paste0("table_res",type)]] <- tab
    out[[paste0("res",type,"_matrix")]] <- values
    all_tables[[type]] <- values;all_full[[type]] <- indiv
  }
  out$res <- do.call(rbind,all_tables)
  out$res_by_quantile <- do.call(rbind,all_full)
  out$completed_nrep <- done
  out
}

run_experiment2 <- function(nrep=NREP,lattices=LATTICES,epsilon=EPSILON,
    kappa=KAPPA,alpha=ALPHA,seed=SEED,n_workers=N_WORKERS,
    batch_size=BATCH_SIZE,output_dir=OUTPUT_DIR) {
  if(!requireNamespace("quantreg",quietly=TRUE))
    stop("Install quantreg first: install.packages('quantreg')")
  integer_scalar <- function(x) length(x)==1L && is.finite(x) && x==round(x)
  stopifnot(integer_scalar(nrep),nrep>0,integer_scalar(seed),seed>=0,
    integer_scalar(n_workers),n_workers>0,integer_scalar(batch_size),batch_size>0,
    is.matrix(lattices),ncol(lattices)==2L,nrow(lattices)>0,
    all(is.finite(lattices)),all(lattices>=3),all(lattices==round(lattices)),
    !anyDuplicated(data.frame(lattices)),
    length(epsilon)>0,all(is.finite(epsilon)),all(epsilon>0 & epsilon<1),!anyDuplicated(epsilon),
    length(kappa)>0,all(is.finite(kappa)),all(kappa>=0),!anyDuplicated(kappa),
    length(alpha)>0,all(is.finite(alpha)),all(alpha>0 & alpha<1),!anyDuplicated(alpha))
  if(seed+100000*nrow(lattices)+nrep>.Machine$integer.max) stop("Seed sequence overflows.")

  widths <- outer(as.vector(lattices),epsilon)
  if(any(abs(widths-round(widths))>1e-10) || any(widths<1))
    stop("epsilon*n1 and epsilon*n2 must be positive integers for exact energy matching.")
  sizes <- outer(apply(lattices,1L,prod),epsilon)
  if(any(sizes<=1)) stop("The smooth hotspot requires epsilon*N > 1.")
  cfg <- list(algorithm_version="experiment2-parallel-v1",nrep=as.integer(nrep),
    lattices=lattices,epsilon=as.numeric(epsilon),kappa=as.numeric(kappa),
    alpha=as.numeric(alpha),seed=as.integer(seed),
    RNGkind=c("Mersenne-Twister","Inversion","Rejection"),
    seed_rule="seed + 100000*lattice_id + replication_id",
    metric="sqrt(pooled SSE / pooled clean squared ordinates)",
    quantile_summary="arithmetic mean of the separately computed quantile NRMSEs",
    R_version=R.version.string,quantreg_version=as.character(utils::packageVersion("quantreg")))
  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  config_path <- file.path(output_dir,"configuration.rds")
  if(file.exists(config_path) && !identical(readRDS(config_path),cfg))
    stop("OUTPUT_DIR contains different scientific settings. Use a new directory.")
  save_checkpoint2(cfg,config_path)
  capture.output(sessionInfo(),file=file.path(output_dir,"sessionInfo.txt"))
  checkpoint_dir <- file.path(output_dir,"checkpoints")
  dir.create(checkpoint_dir,showWarnings=FALSE)
  cl <- NULL
  if(n_workers>1L) {
    cl <- parallel::makePSOCKcluster(as.integer(min(n_workers,nrep,batch_size)))
    on.exit(parallel::stopCluster(cl),add=TRUE)
    versions <- parallel::clusterCall(cl,function(paths) {
      .libPaths(paths)
      if(!requireNamespace("quantreg",quietly=TRUE)) stop("quantreg is missing on a worker.")
      as.character(utils::packageVersion("quantreg"))
    },.libPaths())
    if(any(unlist(versions)!=cfg$quantreg_version)) stop("Worker quantreg versions differ.")
    parallel::clusterExport(cl,c("spg_checked","sqp_checked",
      "periodogram_error_components","experiment2_empty_log","experiment2_one_rep",
      "experiment2_worker","make_scattered_contamination","make_strip_contamination",
      "make_smooth_hotspot_contamination","smooth_hotspot_range"),
      envir=environment(run_experiment2))
  }
  states <- vector("list",nrow(lattices))
  cat("Methods: SPG, SQP at",alpha,"\nEpsilon:",epsilon_labels(epsilon),
      "\nKappa:",kappa,"\nReplications:",nrep,"\n")
  for(g in seq_len(nrow(lattices))) {
    d <- make_spatial_design(lattices[g,1L],lattices[g,2L])
    ranges <- vapply(epsilon,function(e)smooth_hotspot_range(d$n1,d$n2,e),numeric(1L))
    context <- list(config=cfg,design=d,lattice_id=g,smooth_ranges=ranges)
    dims <- c(length(epsilon),length(kappa),length(alpha)+1L,3L)
    path <- file.path(checkpoint_dir,paste0("n",d$n1,"x",d$n2,".rds"))
    if(file.exists(path)) {
      st <- readRDS(path)
      if(!identical(st$config,cfg) || !identical(st$lattice_id,g) ||
         !identical(dim(st$SSE),dims) || !integer_scalar(st$done) || st$done<0 ||
         st$done>nrep || st$COUNT!=st$done*d$m || any(!is.finite(st$SSE)) ||
         any(!is.finite(st$BASE))) stop("Incompatible checkpoint: ",path)
    } else st <- list(config=cfg,lattice_id=g,done=0L,
      SSE=array(0,dims),BASE=numeric(length(alpha)+1L),COUNT=0,
      QC=NULL,issues=experiment2_empty_log())
    if(!is.null(cl) && st$done<nrep) invisible(parallel::clusterCall(cl,function(x) {
      assign(".experiment2_context",x,envir=.GlobalEnv);NULL
    },context))
    cat("\nLattice",d$n1,"x",d$n2,"; frequencies",d$m,
        "; completed",st$done,"/",nrep,"\n")
    while(st$done<nrep) {
      ids <- seq.int(st$done+1L,min(st$done+batch_size,nrep))
      values <- if(is.null(cl)) lapply(ids,experiment2_one_rep,context=context) else
        parallel::parLapplyLB(cl,ids,experiment2_worker)

      for(j in seq_along(ids)) {
        v <- values[[j]]
        if(any(!is.finite(v$SSE)) || any(!is.finite(v$BASE)) || v$COUNT!=d$m)
          stop("Invalid replication; no partial frequencies were accepted.")
        st$SSE <- st$SSE+v$SSE;st$BASE <- st$BASE+v$BASE;st$COUNT <- st$COUNT+v$COUNT
        st$QC <- rbind(st$QC,v$QC)
        if(nrow(v$issues)) st$issues <- rbind(st$issues,v$issues)
        st$done <- ids[j]
      }
      save_checkpoint2(st,path);states[[g]] <- st
      partial <- experiment2_summarize(states,cfg)
      write.csv(partial$res,file.path(output_dir,"res_partial.csv"))
      cat(format(Sys.time(),"%H:%M:%S")," ",d$n1,"x",d$n2,": ",st$done,"/",nrep,"\n",sep="")
      flush.console()
    }
    states[[g]] <- st
  }
  out <- experiment2_summarize(states,cfg)
  stopifnot(all(out$completed_nrep==nrep),all(is.finite(out$res_by_quantile)))
  out$settings <- cfg
  out$contamination_QC <- do.call(rbind,lapply(states,function(x)x$QC))
  out$solver_diagnostics <- do.call(rbind,lapply(states,function(x)x$issues))
  write.csv(out$res,file.path(output_dir,"res.csv"))
  write.csv(out$res_by_quantile,file.path(output_dir,"res_by_quantile.csv"))
  for(type in 1:3) write.csv(out[[paste0("table_res",type)]],
    file.path(output_dir,paste0("table_res",type,".csv")),row.names=FALSE)
  write.csv(out$contamination_QC,file.path(output_dir,"contamination_QC.csv"),row.names=FALSE)
  write.csv(out$solver_diagnostics,file.path(output_dir,"solver_diagnostics.csv"),row.names=FALSE)
  save(list=names(out),envir=list2env(out,parent=emptyenv()),
       file=file.path(output_dir,"experiment2_results.RData"))
  cat("\nNRMSE: SPG and mean over the specified SQP quantiles\n")
  print(signif(out$res,5L))
  if(nrow(out$solver_diagnostics)) warning("Inspect solver_diagnostics.csv before reporting results.")
  invisible(out)
}

if(!isTRUE(getOption("experiment2.functions_only",FALSE))) {
  experiment2_results <- run_experiment2()
  list2env(experiment2_results,envir=environment())

}
