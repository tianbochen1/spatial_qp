if (!requireNamespace("quantreg", quietly = TRUE)) {
  stop("Package 'quantreg' is required. Run install.packages('quantreg').")
}

make_spatial_design <- function(n1, n2, target_index = NULL) {
  n1 <- as.integer(n1)
  n2 <- as.integer(n2)
  N <- n1 * n2

  locations <- expand.grid(
    s1 = seq_len(n1),
    s2 = seq_len(n2)
  )

  full_grid <- expand.grid(
    nu1 = 0:(n1 - 1L),
    nu2 = 0:(n2 - 1L)
  )

  full_grid$neg1 <- (-full_grid$nu1) %% n1
  full_grid$neg2 <- (-full_grid$nu2) %% n2
  full_grid$self_conjugate <-
    full_grid$nu1 == full_grid$neg1 &
    full_grid$nu2 == full_grid$neg2

  key <- full_grid$nu1 * n2 + full_grid$nu2
  neg_key <- full_grid$neg1 * n2 + full_grid$neg2
  keep <- !full_grid$self_conjugate & key < neg_key

  freq <- full_grid[keep, c("nu1", "nu2", "neg1", "neg2")]
  rownames(freq) <- NULL
  freq$omega1 <- 2 * pi * freq$nu1 / n1
  freq$omega2 <- 2 * pi * freq$nu2 / n2

  theta <-
    tcrossprod(locations$s1, freq$omega1) +
    tcrossprod(locations$s2, freq$omega2)

  Cmat <- cos(theta)
  Smat <- sin(theta)

  target_col <- NULL
  target_frequency <- NULL

  if (!is.null(target_index)) {
    target_index <- as.integer(target_index)
    target_col <- which(
      (freq$nu1 == target_index[1L] &
         freq$nu2 == target_index[2L]) |
      (freq$neg1 == target_index[1L] &
         freq$neg2 == target_index[2L])
    )

    if (length(target_col) != 1L) {
      stop("The target frequency must be nonzero and non-self-conjugate.")
    }

    target_frequency <- c(
      target_index[1L] / n1,
      target_index[2L] / n2
    )
  }

  list(
    n1 = n1,
    n2 = n2,
    N = N,
    locations = locations,
    full_grid = full_grid,
    freq = freq,
    Cmat = Cmat,
    Smat = Smat,
    m = nrow(freq),
    target_index = target_index,
    target_col = target_col,
    target_frequency = target_frequency
  )
}

spatial_pg <- function(y, design) {
  y <- as.numeric(y)

  if (length(y) != design$N) {
    stop("The length of y does not agree with the lattice size.")
  }

  z_re <- as.vector(crossprod(design$Cmat, y))
  z_im <- -as.vector(crossprod(design$Smat, y))

  (z_re^2 + z_im^2) / design$N
}

spatial_qp <- function(y, design, alpha = 0.8) {
  y <- as.numeric(y)

  if (length(y) != design$N) {
    stop("The length of y does not agree with the lattice size.")
  }

  ans <- numeric(design$m)

  for (j in seq_len(design$m)) {
    X <- cbind(
      1,
      design$Cmat[, j],
      design$Smat[, j]
    )

    beta <- tryCatch(
      quantreg::rq.fit.fnb(
        x = X,
        y = y,
        tau = alpha
      )$coefficients,
      error = function(e) {
        quantreg::rq.fit.br(
          x = X,
          y = y,
          tau = alpha
        )$coefficients
      }
    )

    ans[j] <-
      design$N * (beta[2L]^2 + beta[3L]^2) / 4
  }

  ans
}

periodogram_to_full_matrix <- function(values, design) {
  if (length(values) != design$m) {
    stop("The periodogram length does not agree with the frequency design.")
  }

  Z <- matrix(
    NA_real_,
    nrow = design$n1,
    ncol = design$n2
  )

  index1 <- cbind(
    design$freq$nu1 + 1L,
    design$freq$nu2 + 1L
  )
  index2 <- cbind(
    design$freq$neg1 + 1L,
    design$freq$neg2 + 1L
  )

  Z[index1] <- values
  Z[index2] <- values
  Z
}

center_periodogram_matrix <- function(values, design, normalize = TRUE) {
  values <- as.numeric(values)

  if (normalize) {
    values <- values / mean(values)
  }

  Z <- periodogram_to_full_matrix(values, design)

  f1 <- (0:(design$n1 - 1L)) / design$n1
  f2 <- (0:(design$n2 - 1L)) / design$n2
  f1[f1 >= 0.5] <- f1[f1 >= 0.5] - 1
  f2[f2 >= 0.5] <- f2[f2 >= 0.5] - 1

  order1 <- order(f1)
  order2 <- order(f2)

  list(
    f1 = f1[order1],
    f2 = f2[order2],
    Z = Z[order1, order2, drop = FALSE]
  )
}

spatial_fisher <- function(x) {

  x_original <- as.numeric(x)
  input_length <- length(x_original)

  if (input_length < 2L) {
    stop("x must contain at least two periodogram ordinates.")
  }

  n_candidate <- sqrt(input_length)

  is_square_grid <-
    abs(n_candidate - round(n_candidate)) <
    sqrt(.Machine$double.eps)

  if (is_square_grid) {

    n <- as.integer(round(n_candidate))

    periodogram_matrix <- matrix(
      x_original,
      nrow = n,
      ncol = n
    )

    frequency_grid <- expand.grid(
      nu1 = 0:(n - 1L),
      nu2 = 0:(n - 1L)
    )

    frequency_grid$neg1 <-
      (-frequency_grid$nu1) %% n

    frequency_grid$neg2 <-
      (-frequency_grid$nu2) %% n

    self_conjugate <-
      frequency_grid$nu1 == frequency_grid$neg1 &
      frequency_grid$nu2 == frequency_grid$neg2

    frequency_key <-
      frequency_grid$nu1 * n +
      frequency_grid$nu2

    conjugate_key <-
      frequency_grid$neg1 * n +
      frequency_grid$neg2

    retain <-
      !self_conjugate &
      frequency_key < conjugate_key

    retained_index <- cbind(
      frequency_grid$nu1[retain] + 1L,
      frequency_grid$nu2[retain] + 1L
    )

    x_test <- periodogram_matrix[
      retained_index
    ]

    original_index <-
      retained_index[, 1L] +
      n * (retained_index[, 2L] - 1L)

  } else {

    x_test <- x_original
    original_index <- seq_along(x_original)
  }

  finite <- is.finite(x_test)

  x_test <- x_test[finite]
  original_index <- original_index[finite]

  m <- length(x_test)

  if (m < 2L) {
    stop("At least two finite periodogram ordinates are required.")
  }

  numerical_tolerance <-
    sqrt(.Machine$double.eps) *
    max(1, max(abs(x_test)))

  if (any(x_test < -numerical_tolerance)) {
    stop("Periodogram ordinates must be nonnegative.")
  }

  x_test[x_test < 0] <- 0

  periodogram_sum <- sum(x_test)

  if (
    !is.finite(periodogram_sum) ||
    periodogram_sum <= 0
  ) {
    stop(
      "The sum of the finite periodogram ordinates must be positive."
    )
  }

  g <- max(x_test) / periodogram_sum

  if (g >= 1 - 100 * .Machine$double.eps) {

    p_value <- 0

  } else if (
    g <= 1 / m + 100 * .Machine$double.eps
  ) {

    p_value <- 1

  } else {

    J <- min(
      m,
      floor(1 / g)
    )

    j <- seq_len(J)

    positive_base <- 1 - j * g

    retain_term <- positive_base > 0

    j <- j[retain_term]
    positive_base <- positive_base[retain_term]

    log_term <-
      lchoose(m, j) +
      (m - 1) * log(positive_base)

    sign_term <-
      ifelse(
        j %% 2L == 1L,
        1,
        -1
      )

    largest_log_term <- max(log_term)

    scaled_sum <- sum(
      sign_term *
        exp(log_term - largest_log_term)
    )

    p_value <-
      exp(largest_log_term) *
      scaled_sum

    p_value <- min(
      1,
      max(0, p_value)
    )
  }

  peak_index <-
    original_index[which.max(x_test)]

  c(
    g = g,
    p.value = p_value,
    reject = as.numeric(p_value < 0.05),
    m = m,
    peak.index = peak_index
  )
}

.spatial_matrix <- function(y, n1, n2) {
  if (is.matrix(y)) {
    if (!all(dim(y) == c(n1, n2))) {
      stop("The dimension of y must be n1 x n2.")
    }
    return(y)
  }

  if (length(y) != n1 * n2) {
    stop("The length of y must be n1 * n2.")
  }

  matrix(
    as.numeric(y),
    nrow = n1,
    ncol = n2
  )
}

spatial_toroidal_distance <- function(n1, n2, center) {
  if (length(center) != 2L) {
    stop("center must contain two coordinates.")
  }

  s1 <- seq_len(n1)
  s2 <- seq_len(n2)

  delta1 <- abs(s1 - center[1L])
  delta2 <- abs(s2 - center[2L])

  delta1 <- pmin(delta1, n1 - delta1)
  delta2 <- pmin(delta2, n2 - delta2)

  outer(
    delta1^2,
    delta2^2,
    FUN = "+"
  )
}

add_scattered_contamination <- function(
    y,
    n1,
    n2,
    kappa = 5,
    h = 1L,
    sigma = 1,
    seed = NULL) {

  if (!is.null(seed)) {
    set.seed(seed)
  }

  Y0 <- .spatial_matrix(y, n1, n2)

  h <- as.integer(h)
  K_h <- h * n2

  if (K_h < 1L || K_h > n1 * n2) {
    stop("h gives an invalid number of contaminated locations.")
  }

  contaminated_index <- sample.int(
    n = n1 * n2,
    size = K_h,
    replace = FALSE
  )

  W <- matrix(
    0,
    nrow = n1,
    ncol = n2
  )

  W[contaminated_index] <- 1

  Y_contaminated <- Y0 + kappa * sigma * W

  list(
    y = as.vector(Y_contaminated),
    field = Y_contaminated,
    weight = W,
    locations = which(W > 0, arr.ind = TRUE),
    type = "scattered",
    kappa = kappa,
    h = h,
    K_h = K_h,
    contamination_rate = K_h / (n1 * n2)
  )
}

add_circular_contamination <- function(
    y,
    n1,
    n2,
    kappa = 5,
    h = 1L,
    sigma = 1,
    center = NULL,
    seed = NULL) {

  if (!is.null(seed)) {
    set.seed(seed)
  }

  Y0 <- .spatial_matrix(y, n1, n2)

  h <- as.integer(h)
  K_h <- h * n2

  if (K_h < 1L || K_h > n1 * n2) {
    stop("h gives an invalid number of contaminated locations.")
  }

  if (is.null(center)) {
    center <- c(
      sample.int(n1, 1L),
      sample.int(n2, 1L)
    )
  }

  distance_squared <- spatial_toroidal_distance(
    n1 = n1,
    n2 = n2,
    center = center
  )

  selected_index <- order(
    as.vector(distance_squared),
    runif(n1 * n2)
  )[seq_len(K_h)]

  W <- matrix(
    0,
    nrow = n1,
    ncol = n2
  )

  W[selected_index] <- 1

  Y_contaminated <- Y0 + kappa * sigma * W

  list(
    y = as.vector(Y_contaminated),
    field = Y_contaminated,
    weight = W,
    locations = which(W > 0, arr.ind = TRUE),
    center = center,
    type = "circular",
    kappa = kappa,
    h = h,
    K_h = K_h,
    contamination_rate = K_h / (n1 * n2)
  )
}

add_strip_contamination <- function(
    y,
    n1,
    n2,
    kappa = 5,
    h = 1L,
    sigma = 1,
    orientation = NULL,
    start = NULL,
    seed = NULL) {

  if (!is.null(seed)) {
    set.seed(seed)
  }

  Y0 <- .spatial_matrix(y, n1, n2)

  h <- as.integer(h)

  if (is.null(orientation)) {
    orientation <- sample(
      c("horizontal", "vertical"),
      size = 1L
    )
  }

  orientation <- match.arg(
    orientation,
    choices = c("horizontal", "vertical")
  )

  W <- matrix(
    0,
    nrow = n1,
    ncol = n2
  )

  if (orientation == "horizontal") {
    if (h < 1L || h > n1) {
      stop("For a horizontal strip, h must be between 1 and n1.")
    }

    if (is.null(start)) {
      start <- sample.int(n1, 1L)
    }

    strip_index <- (
      (start - 1L + 0:(h - 1L)) %% n1
    ) + 1L

    W[strip_index, ] <- 1
  }

  if (orientation == "vertical") {
    if (h < 1L || h > n2) {
      stop("For a vertical strip, h must be between 1 and n2.")
    }

    if (is.null(start)) {
      start <- sample.int(n2, 1L)
    }

    strip_index <- (
      (start - 1L + 0:(h - 1L)) %% n2
    ) + 1L

    W[, strip_index] <- 1
  }

  K_h <- sum(W)
  Y_contaminated <- Y0 + kappa * sigma * W

  list(
    y = as.vector(Y_contaminated),
    field = Y_contaminated,
    weight = W,
    locations = which(W > 0, arr.ind = TRUE),
    orientation = orientation,
    start = start,
    type = "strip",
    kappa = kappa,
    h = h,
    K_h = K_h,
    contamination_rate = K_h / (n1 * n2)
  )
}

add_smooth_hotspot <- function(
    y,
    n1,
    n2,
    kappa = 5,
    h = 1L,
    sigma = 1,
    center = NULL,
    seed = NULL) {

  if (!is.null(seed)) {
    set.seed(seed)
  }

  Y0 <- .spatial_matrix(y, n1, n2)

  h <- as.integer(h)
  K_h <- h * n2

  if (K_h <= 1L || K_h >= n1 * n2) {
    stop("K_h = h * n2 must be between 1 and n1 * n2.")
  }

  if (is.null(center)) {
    center <- c(
      sample.int(n1, 1L),
      sample.int(n2, 1L)
    )
  }

  distance_squared <- spatial_toroidal_distance(
    n1 = n1,
    n2 = n2,
    center = center
  )

  range_equation <- function(r_h) {
    sum(
      exp(-distance_squared / r_h^2)
    ) - K_h
  }

  r_h <- uniroot(
    f = range_equation,
    interval = c(1e-4, 10 * max(n1, n2))
  )$root

  W <- exp(
    -distance_squared / (2 * r_h^2)
  )

  Y_contaminated <- Y0 + kappa * sigma * W

  list(
    y = as.vector(Y_contaminated),
    field = Y_contaminated,
    weight = W,
    center = center,
    range = r_h,
    type = "smooth",
    kappa = kappa,
    h = h,
    K_h = K_h,
    effective_size = sum(W^2),
    contamination_rate = K_h / (n1 * n2)
  )
}

add_rectangular_contamination <- function(
    y,
    n1,
    n2,
    kappa,
    h = NULL,
    sigma = stats::sd(y),
    block_size = NULL,
    start = NULL,
    seed = NULL
) {
  if (length(y) != n1 * n2) {
    stop("The length of y must equal n1 * n2.")
  }

  Y <- matrix(
    as.numeric(y),
    nrow = n1,
    ncol = n2
  )

  if (is.null(block_size)) {
    if (is.null(h)) {
      stop("Either h or block_size must be supplied.")
    }

    K_h <- as.integer(h * n2)

    candidate_rows <- seq_len(n1)
    candidate_cols <- seq_len(n2)

    candidates <- expand.grid(
      nr = candidate_rows,
      nc = candidate_cols
    )

    candidates <- candidates[
      candidates$nr * candidates$nc == K_h,
      ,
      drop = FALSE
    ]

    if (nrow(candidates) == 0L) {
      stop(
        "No rectangular block with exactly h * n2 locations ",
        "fits inside the lattice."
      )
    }

    shape_difference <- abs(
      log(candidates$nr / candidates$nc)
    )

    best <- which.min(shape_difference)

    block_size <- c(
      candidates$nr[best],
      candidates$nc[best]
    )
  }

  block_size <- as.integer(block_size)

  if (length(block_size) != 2L ||
      any(block_size < 1L) ||
      block_size[1L] > n1 ||
      block_size[2L] > n2) {
    stop("block_size must be a valid two-dimensional block size.")
  }

  nr <- block_size[1L]
  nc <- block_size[2L]

  if (is.null(start)) {
    if (!is.null(seed)) {
      set.seed(seed)
    }

    start <- c(
      sample.int(n1 - nr + 1L, size = 1L),
      sample.int(n2 - nc + 1L, size = 1L)
    )
  }

  start <- as.integer(start)

  if (length(start) != 2L ||
      start[1L] < 1L ||
      start[2L] < 1L ||
      start[1L] + nr - 1L > n1 ||
      start[2L] + nc - 1L > n2) {
    stop("The rectangular block extends beyond the lattice.")
  }

  block_rows <- start[1L]:(start[1L] + nr - 1L)
  block_cols <- start[2L]:(start[2L] + nc - 1L)

  W <- matrix(
    0,
    nrow = n1,
    ncol = n2
  )

  W[block_rows, block_cols] <- 1

  Y_contaminated <- Y + kappa * sigma * W

  list(
    y = as.vector(Y_contaminated),
    field = Y_contaminated,
    weight = W,
    block_size = block_size,
    start = start,
    rows = block_rows,
    cols = block_cols,
    contamination_size = sum(W > 0),
    contamination_rate = mean(W > 0),
    kappa = kappa,
    sigma = sigma
  )
}

extract_patch <- function(Y, size) {

  if (!is.matrix(Y)) {
    stop("Y must be a matrix.")
  }

  if (length(size) != 1L ||
      is.na(size) ||
      size < 1L ||
      size != as.integer(size)) {
    stop("size must be a positive integer.")
  }

  size <- as.integer(size)
  nr <- nrow(Y)
  nc <- ncol(Y)

  if (size > nr || size > nc) {
    stop("size cannot exceed the dimensions of Y.")
  }

  row_start <- seq.int(
    from = 1L,
    to   = nr - size + 1L,
    by   = size
  )

  col_start <- seq.int(
    from = 1L,
    to   = nc - size + 1L,
    by   = size
  )

  max_patches <- length(row_start) * length(col_start)

  coordinates <- matrix(
    NA_integer_,
    nrow = max_patches,
    ncol = 2L,
    dimnames = list(NULL, c("row_start", "col_start"))
  )

  K <- 0L

  for (r0 in row_start) {
    rows <- r0:(r0 + size - 1L)

    for (c0 in col_start) {
      cols <- c0:(c0 + size - 1L)

      if (!anyNA(Y[rows, cols, drop = FALSE])) {
        K <- K + 1L
        coordinates[K, ] <- c(r0, c0)
      }
    }
  }

  if (K == 0L) {
    patches <- array(
      vector(typeof(Y), 0L),
      dim = c(0L, size, size)
    )

    attr(patches, "coordinates") <- coordinates[0, , drop = FALSE]
    return(patches)
  }

  coordinates <- coordinates[seq_len(K), , drop = FALSE]

  patches <- array(
    vector(
      mode   = typeof(Y),
      length = as.double(K) * size * size
    ),
    dim = c(K, size, size),
    dimnames = list(
      patch = paste0("patch_", seq_len(K)),
      row   = seq_len(size),
      col   = seq_len(size)
    )
  )

  for (k in seq_len(K)) {
    r0 <- coordinates[k, "row_start"]
    c0 <- coordinates[k, "col_start"]

    patches[k, , ] <- Y[
      r0:(r0 + size - 1L),
      c0:(c0 + size - 1L),
      drop = FALSE
    ]
  }

  attr(patches, "coordinates") <- coordinates
  attr(patches, "source_dimension") <- dim(Y)
  attr(patches, "patch_size") <- size

  patches
}

detrend_all_patches <- function(patches) {

  d <- dim(patches)

  if (length(d) != 3L) {
    stop("patches must be a K x n1 x n2 array.")
  }

  if (anyNA(patches)) {
    stop("patches cannot contain NA values.")
  }

  if (!requireNamespace("quantreg", quietly = TRUE)) {
    stop("Install the quantreg package using install.packages('quantreg').")
  }

  K  <- d[1]
  n1 <- d[2]
  n2 <- d[3]

  s1 <- rep(seq_len(n1), times = n2)
  s2 <- rep(seq_len(n2), each  = n1)

  s1 <- (s1 - mean(s1)) / n1
  s2 <- (s2 - mean(s2)) / n2

  X <- cbind(
    intercept = 1,
    s1 = s1,
    s2 = s2
  )

  detrended <- array(
    NA_real_,
    dim      = d,
    dimnames = dimnames(patches)
  )

  coefficients <- matrix(
    NA_real_,
    nrow = K,
    ncol = 3L,
    dimnames = list(
      paste0("patch_", seq_len(K)),
      c("intercept", "s1", "s2")
    )
  )

  for (k in seq_len(K)) {

    y <- as.vector(patches[k, , ])

    fit <- quantreg::rq.fit(
      x      = X,
      y      = y,
      tau    = 0.5,
      method = "fn"
    )

    beta <- as.numeric(fit$coefficients)

    if (any(!is.finite(beta))) {
      stop("Trend estimation failed for patch ", k, ".")
    }

    residuals_k <- y - drop(X %*% beta)

    detrended[k, , ] <- matrix(
      residuals_k,
      nrow = n1,
      ncol = n2
    )

    coefficients[k, ] <- beta
  }

  patch_coordinates <- attr(patches, "coordinates")
  source_dimension  <- attr(patches, "source_dimension")
  patch_size        <- attr(patches, "patch_size")

  if (!is.null(patch_coordinates)) {
    attr(detrended, "coordinates") <- patch_coordinates
  }

  if (!is.null(source_dimension)) {
    attr(detrended, "source_dimension") <- source_dimension
  }

  if (!is.null(patch_size)) {
    attr(detrended, "patch_size") <- patch_size
  }

  attr(detrended, "trend_coefficients") <- coefficients
  attr(detrended, "detrend_method") <-
    "Two-dimensional median regression plane"

  detrended
}

periodogram_error_components <- function(
    contaminated,
    uncontaminated
) {
  contaminated <- as.numeric(contaminated)
  uncontaminated <- as.numeric(uncontaminated)

  if (length(contaminated) != length(uncontaminated)) {
    stop("The two periodograms must have the same length.")
  }

  keep <-
    is.finite(contaminated) &
    is.finite(uncontaminated)

  if (!any(keep)) {
    stop("No finite periodogram ordinates are available.")
  }

  difference <-
    contaminated[keep] -
    uncontaminated[keep]

  c(
    SSE = sum(difference^2),
    BASE = sum(uncontaminated[keep]^2),
    COUNT = sum(keep)
  )
}

contamination_array_to_table <- function(
    x,
    digits = 3L
) {
  if (length(dim(x)) != 4L) {
    stop(
      "x must have dimensions ",
      "Lattice x Epsilon x Kappa x Method."
    )
  }

  dimension_names <- dimnames(x)

  if (is.null(dimension_names) ||
      any(vapply(dimension_names, is.null, logical(1L)))) {
    stop("All four dimensions of x must have names.")
  }

  output <- expand.grid(
    Lattice = dimension_names[[1L]],
    Epsilon = dimension_names[[2L]],
    Kappa = dimension_names[[3L]],
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )

  for (m in seq_along(dimension_names[[4L]])) {
    method_name <- dimension_names[[4L]][m]

    output[[method_name]] <- as.vector(
      x[, , , m]
    )
  }

  lattice_order <- match(
    output$Lattice,
    dimension_names[[1L]]
  )

  epsilon_order <- match(
    output$Epsilon,
    dimension_names[[2L]]
  )

  kappa_order <- match(
    output$Kappa,
    dimension_names[[3L]]
  )

  output <- output[
    order(lattice_order, epsilon_order, kappa_order),
    ,
    drop = FALSE
  ]

  rownames(output) <- NULL

  numeric_columns <- seq.int(4L, ncol(output))

  output[numeric_columns] <- lapply(
    output[numeric_columns],
    round,
    digits = digits
  )

  output
}

spatial_qp_2d <- function(
    y,
    alpha = 0.5,
    normalize = FALSE
) {

  if (!is.matrix(y) || length(dim(y)) != 2L) {
    stop("y must be a two-dimensional numeric matrix.")
  }

  if (!is.numeric(y)) {
    stop("y must be numeric.")
  }

  if (any(!is.finite(y))) {
    stop("y must not contain NA, NaN, or infinite values.")
  }

  if (length(alpha) != 1L ||
      !is.finite(alpha) ||
      alpha <= 0 ||
      alpha >= 1) {
    stop("alpha must be a single number strictly between 0 and 1.")
  }

  n1 <- nrow(y)
  n2 <- ncol(y)

  if (n1 < 2L || n2 < 2L) {
    stop("Both dimensions of y must be at least 2.")
  }

  y_vector <- as.vector(y)

  design <- make_spatial_design(
    n1 = n1,
    n2 = n2
  )

  qp_retained <- spatial_qp(
    y = y_vector,
    design = design,
    alpha = alpha
  )

  surface <- center_periodogram_matrix(qp_retained,design,normalize)

  if (!identical(dim(surface$Z), c(n1, n2))) {
    stop("The reconstructed SQP surface has an unexpected dimension.")
  }

  surface$alpha <- alpha
  surface$dimension <- c(n1 = n1, n2 = n2)
  surface$normalized <- normalize

  return(surface)
}

spatial_pg_2d <- function(
    Y,
    normalize = FALSE
) {
  if (!is.matrix(Y) || !is.numeric(Y)) {
    stop("Y must be a numeric matrix.")
  }

  if (any(!is.finite(Y))) {
    stop("Y must not contain NA, NaN, or infinite values.")
  }

  n1 <- nrow(Y)
  n2 <- ncol(Y)

  if (n1 < 2L || n2 < 2L) {
    stop("Both dimensions of Y must be at least 2.")
  }

  design <- make_spatial_design(
    n1 = n1,
    n2 = n2
  )

  pg_retained <- spatial_pg(
    y = as.vector(Y),
    design = design
  )

  surface <- center_periodogram_matrix(
    pg_retained,
    design,
    normalize = normalize
  )

  Z <- surface$Z

  attr(Z, "f1") <- surface$f1
  attr(Z, "f2") <- surface$f2
  attr(Z, "normalized") <- normalize

  Z
}

smooth_hotspot_range <- function(n1, n2, epsilon) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon <= 0 || epsilon >= 1) {
    stop("epsilon must be a single number strictly between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  K <- round(epsilon * N)

  if (!is.finite(N) || K <= 1 || K >= N) {
    stop("A finite positive range requires 1 < round(epsilon * N) < N.")
  }

  u1 <- seq_len(n1) - 1
  u2 <- seq_len(n2) - 1
  d1 <- pmin(u1, n1 - u1)
  d2 <- pmin(u2, n2 - u2)

  objective <- function(r) {
    if (r == 0) return(1 - K)

    sum(exp(-(d1 / r)^2)) *
      sum(exp(-(d2 / r)^2)) - K
  }

  upper <- max(n1, n2)
  while (objective(upper) < 0) {
    upper <- 2 * upper
  }

  stats::uniroot(
    f = objective,
    interval = c(0, upper),
    tol = 1e-10,
    check.conv = TRUE
  )$root
}

make_scattered_contamination <- function(n1, n2, epsilon,
                                         ordering = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon < 0 || epsilon > 1) {
    stop("epsilon must be a single number between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  if (!is.finite(N)) stop("The lattice size must be finite.")
  K <- round(epsilon * N)

  if (is.null(ordering)) {
    ordering <- sample.int(N)
  } else if (!is.numeric(ordering) || is.complex(ordering) ||
             length(ordering) != N || any(!is.finite(ordering)) ||
             any(ordering != floor(ordering)) ||
             any(ordering < 1 | ordering > N) ||
             anyDuplicated(ordering) > 0L) {
    stop("ordering must be a permutation of seq_len(n1 * n2).")
  }

  index <- ordering[seq_len(K)]

  W <- matrix(0, nrow = n1, ncol = n2)
  W[index] <- 1

  list(
    weight = W,
    index = index,
    K = K,
    epsilon_actual = K / N
  )
}

make_strip_contamination <- function(n1, n2, epsilon,
                                     orientation = NULL,
                                     start = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon < 0 || epsilon > 1) {
    stop("epsilon must be a single number between 0 and 1.")
  }

  if (is.null(orientation)) {
    orientation <- sample(c("horizontal", "vertical"), size = 1L)
  }

  if (!is.character(orientation) || length(orientation) != 1L ||
      is.na(orientation) ||
      !orientation %in% c("horizontal", "vertical")) {
    stop("orientation must be 'horizontal' or 'vertical'.")
  }

  axis_length <- if (orientation == "horizontal") n1 else n2

  if (is.null(start)) {
    start <- sample.int(axis_length, size = 1L)
  }

  if (!valid_size(start) || start > axis_length) {
    stop("start must be an integer within the selected axis.")
  }

  width <- if (epsilon == 0) {
    0
  } else {
    max(1, round(epsilon * axis_length))
  }

  strip_index <- ((start - 1 + seq_len(width) - 1) %% axis_length) + 1

  W <- matrix(0, nrow = n1, ncol = n2)

  if (orientation == "horizontal") {
    W[strip_index, ] <- 1
  } else {
    W[, strip_index] <- 1
  }

  list(
    weight = W,
    orientation = orientation,
    start = start,
    width = width,
    strip_index = strip_index,
    K = sum(W),
    epsilon_actual = width / axis_length
  )
}

make_smooth_hotspot_contamination <- function(n1, n2, epsilon,
                                              center = NULL,
                                              range = NULL) {
  valid_size <- function(x) {
    is.numeric(x) && !is.complex(x) && length(x) == 1L &&
      is.finite(x) && x >= 1 && x == floor(x)
  }

  if (!valid_size(n1) || !valid_size(n2)) {
    stop("n1 and n2 must be positive integers.")
  }

  if (!is.numeric(epsilon) || is.complex(epsilon) ||
      length(epsilon) != 1L || !is.finite(epsilon) ||
      epsilon <= 0 || epsilon >= 1) {
    stop("epsilon must be a single number strictly between 0 and 1.")
  }

  N <- as.double(n1) * as.double(n2)
  K <- round(epsilon * N)

  if (!is.finite(N) || K <= 1 || K >= N) {
    stop("A finite positive range requires 1 < round(epsilon * N) < N.")
  }

  if (is.null(center)) {
    center <- c(sample.int(n1, 1L), sample.int(n2, 1L))
  }

  if (!is.numeric(center) || is.complex(center) ||
      length(center) != 2L || any(!is.finite(center)) ||
      any(center != floor(center)) ||
      any(center < 1) || any(center > c(n1, n2))) {
    stop("center must contain valid integer row and column indices.")
  }

  if (is.null(range)) {
    range <- smooth_hotspot_range(
      n1 = n1, n2 = n2, epsilon = epsilon
    )
  }

  if (!is.numeric(range) || is.complex(range) ||
      length(range) != 1L || !is.finite(range) || range <= 0) {
    stop("range must be a single finite positive number.")
  }

  d1 <- abs(seq_len(n1) - center[1L])
  d2 <- abs(seq_len(n2) - center[2L])
  d1 <- pmin(d1, n1 - d1)
  d2 <- pmin(d2, n2 - d2)

  W <- exp(-outer((d1 / range)^2, (d2 / range)^2, "+") / 2)

  effective_size <- sum(W^2)

  if (abs(effective_size - K) > 1e-7 * max(1, K)) {
    stop(
      "range is inconsistent with epsilon; recompute it with smooth_hotspot_range()."
    )
  }

  list(
    weight = W,
    center = center,
    range = range,
    K = K,
    effective_size = effective_size,
    epsilon_actual = effective_size / N
  )
}
