RUN_PARTS <- getOption("d94.run_parts", c(1L, 2L))
PROJECT_DIR <- getOption("d94.project_dir", file.path(getwd(), "Brodatz_D94_SQP"))
ANALYSIS_N <- getOption("d94.analysis_n", 128L)
AUTO_INSTALL <- TRUE
PLOT_ONLY <- getOption("d94.plot_only", FALSE)
FORCE_RECOMPUTE <- getOption("d94.force_recompute", FALSE)

ALPHAS <- c(SQP01 = 0.1, SQP05 = 0.5, SQP09 = 0.9)
CHUNK_SIZE <- 64L
SAVE_PNG <- TRUE                     
PNG_DPI <- 160L
LOG_FLOOR <- 1e-10                   
PROFILE_MAX_FREQ <- 0.5              
MAKE_INTENSITY_MAP <- TRUE           
QR_EPS <- 1e-6                       
ESTIMATOR_VERSION <- "D94-spatial-QR-v1"

LOWPASS_SIGMA_FACTOR <- 0.5

d94_packages <- function(pkgs) {
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) && AUTO_INSTALL) {
    install.packages(missing, repos = "https://cloud.r-project.org")
  }
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Install the required R packages first: ",
                            paste(missing, collapse = ", "), call. = FALSE)
}

d94_paths <- function() {
  for (sub in c("", "raw", "cache", "figures", "tables")) {
    dir.create(file.path(PROJECT_DIR, sub), recursive = TRUE, showWarnings = FALSE)
  }
  list(raw = file.path(PROJECT_DIR, "raw", "1.1.12.tiff"),
       data = file.path(PROJECT_DIR, "D94_preprocessed.RData"),
       results = file.path(PROJECT_DIR, "D94_results.RData"),
       cache = file.path(PROJECT_DIR, "cache"),
       figures = file.path(PROJECT_DIR, "figures"),
       tables = file.path(PROJECT_DIR, "tables"))
}

d94_hash <- function(x) {
  f <- tempfile(fileext = ".rds")
  on.exit(unlink(f), add = TRUE)
  saveRDS(x, f, compress = FALSE, version = 2)
  unname(tools::md5sum(f))
}

d94_read_object <- function(path, name) {
  if (!file.exists(path)) stop("Missing file: ", path, call. = FALSE)
  e <- new.env(parent = emptyenv())
  load(path, envir = e)
  if (!exists(name, envir = e, inherits = FALSE)) {
    stop("Expected object '", name, "' in ", path, call. = FALSE)
  }
  get(name, envir = e, inherits = FALSE)
}

d94_write_csv <- function(x, name, paths) {
  write.csv(x, file.path(paths$tables, name), row.names = FALSE, na = "",
            fileEncoding = "UTF-8")
}

d94_read_tiff <- function(path) {
  x <- tiff::readTIFF(path, native = FALSE, convert = FALSE)
  if (!is.matrix(x) || !identical(as.integer(dim(x)), c(512L, 512L))) {
    stop("Expected the original 512 x 512 grayscale D94 TIFF; check the file.")
  }
  if (any(!is.finite(x)) || min(x) < 0 || max(x) > 1) {
    stop("The TIFF must contain finite grayscale values in [0,1].")
  }
  x
}

d94_download <- function(path) {
  if (file.exists(path)) {
    invisible(d94_read_tiff(path))
    message("Using existing TIFF: ", path)
    return(invisible(path))
  }
  url <- "https://sipi.usc.edu/database/download.php?img=1.1.12&vol=textures"
  temp <- tempfile(pattern = "D94_download_", tmpdir = dirname(path), fileext = ".tiff")
  on.exit(unlink(temp), add = TRUE)
  old <- options(timeout = max(180, getOption("timeout", 60)))
  on.exit(options(old), add = TRUE)
  message("Downloading USC-SIPI D94 (original TIFF, about 256 KB)...")
  status <- tryCatch({
    download.file(url, temp, mode = "wb", quiet = FALSE)
  }, error = function(e) e)
  valid <- !inherits(status, "error") && identical(as.integer(status), 0L)
  if (valid) valid <- tryCatch({ d94_read_tiff(temp); TRUE }, error = function(e) FALSE)
  if (!valid) {
    stop("Download failed or did not return the original TIFF. Download 1.1.12 from\n",
         "https://sipi.usc.edu/database/database.php?image=12&volume=textures\n",
         "and save it as: ", path, "\nThen rerun PART 1.", call. = FALSE)
  }
  if (!file.copy(temp, path, overwrite = FALSE)) stop("Could not save TIFF: ", path)
  invisible(path)
}

d94_gaussian_weights <- function(n_in, n_out, sigma_factor) {
  if (n_out > n_in) stop("Upsampling is not used in this experiment.")
  if (n_out == n_in) return(diag(n_in))
  scale <- n_in / n_out
  sigma <- sigma_factor * scale
  centers <- (seq_len(n_out) - 0.5) * scale + 0.5
  distance <- outer(centers, seq_len(n_in), "-")
  w <- exp(-0.5 * (distance / sigma)^2)
  w[abs(distance) > 4 * sigma] <- 0

  w / rowSums(w)
}

d94_part1 <- function() {
  if (length(ANALYSIS_N) != 1L || !is.finite(ANALYSIS_N) ||
      ANALYSIS_N != as.integer(ANALYSIS_N) || ANALYSIS_N < 16L || ANALYSIS_N > 510L) {
    stop("ANALYSIS_N must be an integer between 16 and 510.")
  }
  if (!is.finite(LOWPASS_SIGMA_FACTOR) || LOWPASS_SIGMA_FACTOR <= 0) {
    stop("LOWPASS_SIGMA_FACTOR must be positive.")
  }
  d94_packages("tiff")
  paths <- d94_paths()
  d94_download(paths$raw)
  original <- d94_read_tiff(paths$raw)
  zero_rows <- which(rowSums(abs(original)) == 0)
  if (!identical(zero_rows, c(511L, 512L))) {
    stop("Unexpected zero-row pattern. Check that the file is USC-SIPI 1.1.12.")
  }
  cleaned <- original[1:510, , drop = FALSE]

  side <- min(dim(cleaned))
  r0 <- (nrow(cleaned) - side) %/% 2L + 1L
  c0 <- (ncol(cleaned) - side) %/% 2L + 1L
  rows <- seq.int(r0, length.out = side)
  cols <- seq.int(c0, length.out = side)
  roi <- cleaned[rows, cols, drop = FALSE]
  W <- d94_gaussian_weights(side, as.integer(ANALYSIS_N), LOWPASS_SIGMA_FACTOR)
  image <- W %*% roi %*% t(W)
  if (any(!is.finite(image)) || sd(as.vector(image)) <= 1e-8) {
    stop("The processed image is invalid or nearly constant.")
  }
  Y <- image - mean(image)  
  pixel_scale <- side / ANALYSIS_N
  metadata <- list(
    dataset = "USC-SIPI Brodatz D94, Brick wall, original 1.1.12",
    source_page = "https://sipi.usc.edu/database/database.php?image=12&volume=textures",
    download_url = "https://sipi.usc.edu/database/download.php?img=1.1.12&vol=textures",
    source_md5 = unname(tools::md5sum(paths$raw)),
    original_dim = dim(original), removed_zero_rows = zero_rows,
    roi_rows = range(rows), roi_cols = range(cols), roi_dim = dim(roi),
    analysis_dim = dim(Y), original_pixels_per_processed_pixel = pixel_scale,
    lowpass = "Separable Gaussian resampling, four-sigma truncation; normalized boundaries",
    sigma_input_pixels = if (ANALYSIS_N < side) LOWPASS_SIGMA_FACTOR * pixel_scale else 0,
    preprocessing = "Remove two zero rows; central square; Gaussian downsample; subtract mean",
    histogram_equalization = FALSE, jitter_added = FALSE, spatial_taper = FALSE,
    frequency_units = "cycles per processed pixel",
    frequency_axes = "f1: matrix rows (vertical); f2: matrix columns (horizontal)",
    created = format(Sys.time(), tz = "UTC", usetz = TRUE))
  D94_data <- list(original = original, cleaned = cleaned, roi = roi,
                   image = image, Y = Y, metadata = metadata)
  D94_data$data_signature <- d94_hash(list(Y = Y, metadata$preprocessing,
                                         metadata$sigma_input_pixels))
  save(D94_data, file = paths$data, compress = "xz")
  qc <- data.frame(stage = c("Downloaded", "Zero rows removed", "Central square", "Analysis"),
                   rows = c(nrow(original), nrow(cleaned), nrow(roi), nrow(image)),
                   columns = c(ncol(original), ncol(cleaned), ncol(roi), ncol(image)),
                   mean = vapply(list(original, cleaned, roi, image), mean, numeric(1)),
                   sd = vapply(list(original, cleaned, roi, image), function(z) sd(c(z)), numeric(1)))
  d94_write_csv(qc, "preprocessing_QC.csv", paths)
  capture.output(str(metadata), file = file.path(PROJECT_DIR, "preprocessing_notes.txt"))
  message("PART 1 complete: ", paths$data)
  message("Analysis image: ", nrow(Y), " x ", ncol(Y),
          "; original field of view: ", side, " x ", side)
  invisible(D94_data)
}

d94_design <- function(n1, n2) {
  n1 <- as.integer(n1); n2 <- as.integer(n2)
  locations <- expand.grid(s1 = seq_len(n1), s2 = seq_len(n2))
  f <- expand.grid(nu1 = 0:(n1 - 1L), nu2 = 0:(n2 - 1L))
  f$neg1 <- (-f$nu1) %% n1
  f$neg2 <- (-f$nu2) %% n2
  self <- f$nu1 == f$neg1 & f$nu2 == f$neg2
  keep <- !self & f$nu1 * n2 + f$nu2 < f$neg1 * n2 + f$neg2
  f <- f[keep, , drop = FALSE]
  rownames(f) <- NULL
  f$omega1 <- 2 * pi * f$nu1 / n1
  f$omega2 <- 2 * pi * f$nu2 / n2
  list(n1 = n1, n2 = n2, N = n1 * n2, locations = locations, freq = f, m = nrow(f))
}

d94_empty_warnings <- function() {
  data.frame(method = character(), frequency_index = integer(),
             nu1 = integer(), nu2 = integer(), solver = character(), message = character())
}

d94_compute <- function(data, paths, request_signature) {
  d94_packages("quantreg")
  Y <- data$Y
  design <- d94_design(nrow(Y), ncol(Y))
  methods <- c("SPG", names(ALPHAS))
  solver_version <- as.character(packageVersion("quantreg"))
  cache_signature <- d94_hash(list(request_signature, solver_version))
  cache_file <- file.path(paths$cache, paste0("D94_", cache_signature, ".rds"))
  state <- NULL
  if (file.exists(cache_file) && !FORCE_RECOMPUTE) {
    state <- tryCatch(readRDS(cache_file), error = function(e) NULL)
    if (!is.null(state) && !identical(state$signature, cache_signature)) state <- NULL
  }
  if (is.null(state)) {
    spectra <- matrix(NA_real_, design$m, length(methods), dimnames = list(NULL, methods))

    t0 <- proc.time()[3L]
    pg <- Mod(fft(Y))^2 / design$N
    spectra[, "SPG"] <- pg[cbind(design$freq$nu1 + 1L, design$freq$nu2 + 1L)]
    elapsed <- setNames(numeric(length(methods)), methods)
    elapsed["SPG"] <- proc.time()[3L] - t0
    state <- list(signature = cache_signature, spectra = spectra,
                  done = rep(FALSE, design$m), seconds = elapsed,
                  design_seconds = 0, warnings = d94_empty_warnings())
  }
  message("Retained frequency pairs: ", design$m, "; quantile levels: ",
          paste(ALPHAS, collapse = ", "))
  message("Completed frequency pairs in cache: ", sum(state$done), "/", design$m)
  y <- as.vector(Y)
  pending <- which(!state$done)
  report_time <- proc.time()[3L]
  if (length(pending)) for (start in seq.int(1L, length(pending), by = CHUNK_SIZE)) {
    jj <- pending[start:min(length(pending), start + CHUNK_SIZE - 1L)]
    t0 <- proc.time()[3L]
    phase <- tcrossprod(design$locations$s1, design$freq$omega1[jj]) +
             tcrossprod(design$locations$s2, design$freq$omega2[jj])
    Cmat <- cos(phase); Smat <- sin(phase)
    rm(phase)
    state$design_seconds <- state$design_seconds + proc.time()[3L] - t0
    events <- list()
    record <- function(method, j, solver, msg) {
      events[[length(events) + 1L]] <<- data.frame(method = method, frequency_index = j,
        nu1 = design$freq$nu1[j], nu2 = design$freq$nu2[j], solver = solver, message = msg)
    }
    for (method in names(ALPHAS)) {
      t0 <- proc.time()[3L]
      for (k in seq_along(jj)) {
        j <- jj[k]
        X <- cbind(1, Cmat[, k], Smat[, k])
        beta <- tryCatch(withCallingHandlers(
          quantreg::rq.fit.fnb(x = X, y = y, tau = ALPHAS[[method]], eps = QR_EPS)$coefficients,
          warning = function(w) {
            record(method, j, "fnb", conditionMessage(w)); invokeRestart("muffleWarning")
          }), error = function(e) {
            record(method, j, "fnb error -> br", conditionMessage(e)); NULL
          })
        if (length(beta) != 3L || any(!is.finite(beta))) {
          record(method, j, "br fallback", "No finite three-coefficient fnb solution")
          beta <- withCallingHandlers(
            quantreg::rq.fit.br(x = X, y = y, tau = ALPHAS[[method]])$coefficients,
            warning = function(w) {
              record(method, j, "br", conditionMessage(w)); invokeRestart("muffleWarning")
            })
        }
        if (length(beta) != 3L || any(!is.finite(beta))) {
          stop("Invalid QR result at frequency index ", j, " for ", method)
        }
        state$spectra[j, method] <- design$N * sum(beta[2:3]^2) / 4
      }
      state$seconds[method] <- state$seconds[method] + proc.time()[3L] - t0
    }
    state$done[jj] <- TRUE
    if (length(events)) state$warnings <- rbind(state$warnings, do.call(rbind, events))
    saveRDS(state, cache_file, compress = FALSE)
    if (proc.time()[3L] - report_time >= 15 || all(state$done)) {
      message("  ", sum(state$done), "/", design$m, " frequency pairs; all three quantiles")
      report_time <- proc.time()[3L]
    }
  }
  if (!all(state$done) || any(!is.finite(state$spectra)) || any(state$spectra < 0)) {
    stop("Incomplete or invalid spectra; no final result was saved.")
  }
  if (any(colSums(state$spectra) <= 0)) stop("A spectrum has zero total mass.")
  list(request_signature = request_signature, data_signature = data$data_signature,
       estimator_version = ESTIMATOR_VERSION, alphas = ALPHAS,
       qr_eps = QR_EPS, quantreg_version = solver_version, design = design,
       spectra = state$spectra, seconds = state$seconds,
       design_seconds = state$design_seconds, warnings = state$warnings,
       preprocessing = data$metadata,
       computation_note = "SPG: FFT time; SQP: QR fitting time. Shared design time is separate.",
       created = format(Sys.time(), tz = "UTC", usetz = TRUE))
}

d94_surface <- function(values, design, normalize = FALSE) {
  if (normalize) values <- values / (2 * sum(values))
  Z <- matrix(NA_real_, design$n1, design$n2)
  f <- design$freq
  Z[cbind(f$nu1 + 1L, f$nu2 + 1L)] <- values
  Z[cbind(f$neg1 + 1L, f$neg2 + 1L)] <- values
  f1 <- (0:(design$n1 - 1L)) / design$n1
  f2 <- (0:(design$n2 - 1L)) / design$n2
  f1[f1 >= 0.5] <- f1[f1 >= 0.5] - 1
  f2[f2 >= 0.5] <- f2[f2 >= 0.5] - 1
  list(f1 = sort(f1), f2 = sort(f2), Z = Z[order(f1), order(f2), drop = FALSE])
}

d94_fold_profile <- function(f, mass, n) {

  k <- as.integer(round(abs(f) * n))
  out <- numeric(n %/% 2L + 1L)
  for (j in seq_along(k)) out[k[j] + 1L] <- out[k[j] + 1L] + mass[j]
  data.frame(frequency = (0:(n %/% 2L)) / n, mass = out)
}

d94_summaries <- function(results, data, paths) {
  design <- results$design
  methods <- colnames(results$spectra)
  rows <- list(); profiles <- list()
  p0 <- results$spectra[, "SPG"] / sum(results$spectra[, "SPG"])
  jsd <- function(p, q) {
    m <- (p + q) / 2
    a <- p > 0; b <- q > 0
    0.5 * (sum(p[a] * log(p[a] / m[a])) + sum(q[b] * log(q[b] / m[b])))
  }
  for (method in methods) {
    v <- results$spectra[, method]
    p <- v / sum(v)
    surf <- d94_surface(v, design, normalize = TRUE)
    one <- d94_fold_profile(surf$f1, rowSums(surf$Z, na.rm = TRUE), design$n1)
    two <- d94_fold_profile(surf$f2, colSums(surf$Z, na.rm = TRUE), design$n2)
    profiles[[length(profiles) + 1L]] <- data.frame(method = method, axis = "f1_rows", one)
    profiles[[length(profiles) + 1L]] <- data.frame(method = method, axis = "f2_columns", two)
    rows[[length(rows) + 1L]] <- data.frame(method = method,
      total_raw_pair_power = sum(v), largest_pair_mass = max(p),
      normalized_pair_entropy = -sum(p[p > 0] * log(p[p > 0])) / log(length(p)),
      JSD_to_SPG = jsd(p, p0),
      fraction_ordinates_below_1e_minus12_relative = mean(v <= max(v) * 1e-12))
  }
  profiles <- do.call(rbind, profiles)
  profiles$frequency_original_pixel <- profiles$frequency /
    data$metadata$original_pixels_per_processed_pixel
  d94_write_csv(profiles, "frequency_profiles.csv", paths)
  d94_write_csv(do.call(rbind, rows), "spectral_summary.csv", paths)
  d94_write_csv(data.frame(method = names(results$seconds), seconds = as.numeric(results$seconds)),
                "computation_time.csv", paths)
  d94_write_csv(results$warnings, "solver_warnings.csv", paths)
  writeLines(c(
    "All metrics use unsmoothed spectra and omit self-conjugate Fourier points.",
    "JSD_to_SPG measures difference, not accuracy or robustness; natural logarithms are used.",
    "Entropy uses one representative per conjugate pair; larger entropy means flatter spectra.",
    "Normalized 2-D surfaces sum to one over all finite ordinates.",
    "Each folded marginal profile also sums to one; f=0 marginal mass is retained.",
    "Intensity-region maps are descriptive only. Every SQP is fitted to all pixels.",
    "Both light and dark features may affect any quantile-regression fit.",
    "No inferential or superiority claim follows from this single-image illustration.",
    paste("Shared QR design construction time (seconds):", results$design_seconds)),
    file.path(PROJECT_DIR, "analysis_notes.txt"))
  profiles
}

d94_save_plot <- function(stem, width, height, draw, paths) {
  draw_device <- function(type) {
    if (type == "pdf") {
      grDevices::pdf(file.path(paths$figures, paste0(stem, ".pdf")), width = width,
                    height = height, onefile = TRUE, useDingbats = FALSE)
    } else {
      grDevices::png(file.path(paths$figures, paste0(stem, ".png")), width = width,
                    height = height, units = "in", res = PNG_DPI)
    }
    on.exit(grDevices::dev.off(), add = TRUE)
    draw()
  }
  draw_device("pdf")
  if (SAVE_PNG) draw_device("png")
}

d94_image_panel <- function(x, title, axes = FALSE) {
  plot.new()
  plot.window(xlim = c(0, ncol(x)), ylim = c(nrow(x), 0), asp = 1,
              xaxs = "i", yaxs = "i")
  rasterImage(as.raster(x, max = 1), 0, nrow(x), ncol(x), 0, interpolate = FALSE)
  box()
  title(main = title, line = 0.5)
  if (axes) { axis(1, cex.axis = 0.75); axis(2, las = 1, cex.axis = 0.75) }
}

d94_plot_all <- function(data, results, profiles, paths) {
  d94_packages("plot3D")
  methods <- colnames(results$spectra)
  titles <- c(list("SPG"), lapply(unname(results$alphas), function(a) bquote(SQP~(alpha == .(a)))))
  names(titles) <- methods
  cols <- setNames(c("#222222", "#0072B2", "#009E73", "#D55E00"), methods)
  ltys <- setNames(c(1, 2, 3, 4), methods)
  raw <- lapply(methods, function(m) d94_surface(results$spectra[, m], results$design))
  normalized <- lapply(methods, function(m) d94_surface(results$spectra[, m], results$design, TRUE))
  log_norm <- lapply(normalized, function(s) { s$Z <- log10(s$Z + LOG_FLOOR); s })
  pal <- plot3D::jet.col(128)

  d94_save_plot("01_image_and_preprocessing", 11.5, 4.3, function() {
    par(mfrow = c(1, 3), mar = c(2.5, 2.5, 2.5, 0.8), mgp = c(1.5, 0.4, 0), oma = c(1, 0, 0, 0))
    d94_image_panel(data$original, "(a) Original D94: 512 x 512", TRUE)
    rect(data$metadata$roi_cols[1] - 1, data$metadata$roi_rows[1] - 1,
         data$metadata$roi_cols[2], data$metadata$roi_rows[2], border = "#D55E00", lwd = 1)
    d94_image_panel(data$roi, "(b) Retained field: 510 x 510", TRUE)
    d94_image_panel(data$image, sprintf("(c) Analysis image: %d x %d", nrow(data$Y), ncol(data$Y)), TRUE)
    mtext("The same processed image is used for SPG and all three SQPs.", side = 1, outer = TRUE, cex = 0.8)
  }, paths)

  if (MAKE_INTENSITY_MAP) d94_save_plot("02_intensity_regions", 12.5, 3.9, function() {
    q <- quantile(data$image, c(0.1, 0.45, 0.55, 0.9), names = FALSE)
    par(mfrow = c(1, 4), mar = c(1, 0.5, 2.5, 0.5), oma = c(2, 0, 0, 0))
    d94_image_panel(data$image, "Analysis image")

    d94_image_panel(1 - (data$image <= q[1]), "Lower tail: Y <= Q(0.1)")
    d94_image_panel(1 - (data$image >= q[2] & data$image <= q[3]), "Middle: Q(0.45) to Q(0.55)")
    d94_image_panel(1 - (data$image >= q[4]), "Upper tail: Y >= Q(0.9)")
    mtext("Black pixels identify intensity regions only; all SQPs use every pixel.",
          side = 1, outer = TRUE, line = 0.3, cex = 0.85)
  }, paths)

  d94_save_plot("03_frequency_profiles", 11, 7.5, function() {
    par(mfrow = c(2, 2), mar = c(3.8, 4.1, 2.4, 0.8), mgp = c(2.4, 0.6, 0),
        oma = c(1.1, 0, 0, 0), las = 1)
    for (log_scale in c(FALSE, TRUE)) for (ax in c("f1_rows", "f2_columns")) {
      sub <- profiles[profiles$axis == ax & profiles$frequency <= PROFILE_MAX_FREQ, ]
      yr <- if (log_scale) range(log10(sub$mass + LOG_FLOOR)) else c(0, max(sub$mass) * 1.08)
      title <- if (ax == "f1_rows") "Freq 1: variation along rows" else "Freq 2: variation along columns"
      plot(NA, xlim = c(0, PROFILE_MAX_FREQ), ylim = yr, xaxs = "i",
           xlab = "Frequency (cycles / processed pixel)",
           ylab = if (log_scale) "log10(marginal mass + floor)" else "Marginal spectral mass",
           main = title, cex.main = 1, cex.lab = 0.95)
      abline(h = pretty(yr), col = "grey92", lwd = 0.7)
      for (method in methods) {
        s <- sub[sub$method == method, ]
        values <- if (log_scale) log10(s$mass + LOG_FLOOR) else s$mass
        lines(s$frequency, values, col = cols[[method]], lty = ltys[[method]], lwd = 1.6)
      }
      if (!log_scale) legend("topright", legend = methods, col = cols, lty = ltys,
                             lwd = 1.7, bty = "n", cex = 0.82)
      box()
    }
    mtext("Positive and negative frequencies are folded together; f=0 marginal mass is retained.",
          side = 1, outer = TRUE, cex = 0.78)
  }, paths)

  common_log <- range(unlist(lapply(log_norm, function(s) s$Z)), finite = TRUE)
  d94_save_plot("04_heatmaps_log_normalized", 10, 8.8, function() {
    par(mfrow = c(2, 2), mar = c(3.5, 3.3, 2.2, 3.8), mgp = c(2, 0.5, 0), oma = c(1.4, 0, 0, 0))
    for (i in seq_along(methods)) {
      s <- log_norm[[i]]
      plot3D::image2D(x = s$f1, y = s$f2, z = s$Z, asp = 1,
        xlab = "Freq 1 (rows)", ylab = "Freq 2 (columns)", main = titles[[i]],
        col = pal, clim = common_log, NAcol = "grey85", contour = FALSE,
        colkey = list(cex.axis = 0.7, width = 0.6, length = 0.85), cex.axis = 0.8)
    }
    mtext(paste0("log10(p + ", format(LOG_FLOOR, scientific = TRUE),
                 "); shared color scale; zero frequency centered; grey points omitted."),
          side = 1, outer = TRUE, cex = 0.78)
  }, paths)

  for (kind in c("raw", "log_normalized")) {
    surfaces <- if (kind == "raw") raw else log_norm
    common_zlim <- if (kind == "raw") c(0, max(unlist(lapply(raw, function(s) s$Z)), na.rm = TRUE)) else common_log
    current_kind <- kind; current_surfaces <- surfaces; current_zlim <- common_zlim
    d94_save_plot(paste0("05_persp3D_", kind), 10.5, 8.8, function() {
      par(mfrow = c(2, 2), oma = c(1.5, 0, 1.2, 0))
      for (i in seq_along(methods)) {
        s <- current_surfaces[[i]]
        par(mar = c(3, 3, 1, 2), mgp = c(2, 0.5, 0))
        plot3D::persp3D(x = s$f1, y = s$f2, z = s$Z,
          xlab = "Freq 1", ylab = "Freq 2",
          zlab = if (current_kind == "raw") "Periodogram" else "log10(p + floor)",
          phi = 30, theta = 20, main = titles[[i]],
          zlim = current_zlim, clim = current_zlim, col = pal,
          colkey = list(cex.axis = 0.65, width = 0.5, length = 0.8),
          border = NA, bty = "b", ticktype = "detailed", cex.axis = 0.65, cex.lab = 0.8)
      }
      mtext("Freq 1: rows; Freq 2: columns. Units: cycles / processed pixel. Shared z/color limits.",
            side = 1, outer = TRUE, cex = 0.75)
    }, paths)
  }
  invisible(NULL)
}

d94_part2 <- function() {
  if (!identical(names(ALPHAS), c("SQP01", "SQP05", "SQP09")) ||
      !isTRUE(all.equal(unname(ALPHAS), c(0.1, 0.5, 0.9)))) {
    stop("This four-panel illustration expects ALPHAS = c(SQP01=.1, SQP05=.5, SQP09=.9).")
  }
  if (CHUNK_SIZE < 1 || CHUNK_SIZE != as.integer(CHUNK_SIZE)) stop("Invalid CHUNK_SIZE.")
  if (!is.finite(LOG_FLOOR) || LOG_FLOOR <= 0 || PROFILE_MAX_FREQ <= 0 || PROFILE_MAX_FREQ > 0.5) {
    stop("Invalid plotting parameters.")
  }
  if (PLOT_ONLY && FORCE_RECOMPUTE) stop("PLOT_ONLY and FORCE_RECOMPUTE cannot both be TRUE.")
  paths <- d94_paths()
  data <- d94_read_object(paths$data, "D94_data")
  if (!is.matrix(data$Y) || any(!is.finite(data$Y))) stop("Invalid Y in preprocessed RData.")
  signature <- d94_hash(list(ESTIMATOR_VERSION, data$Y, ALPHAS, QR_EPS))
  results <- NULL
  if (file.exists(paths$results) && !FORCE_RECOMPUTE) {
    candidate <- d94_read_object(paths$results, "D94_results")
    if (identical(candidate$request_signature, signature)) results <- candidate
  }
  if (is.null(results)) {
    if (PLOT_ONLY) stop("No matching completed results. Set PLOT_ONLY=FALSE and run PART 2 first.")
    results <- d94_compute(data, paths, signature)
    D94_results <- results
    save(D94_results, file = paths$results, compress = "xz")
    capture.output(sessionInfo(), file = file.path(PROJECT_DIR, "computation_sessionInfo.txt"))
    message("Saved complete spectra: ", paths$results)
  } else message("Using completed spectra; no QR recomputation is needed.")
  profiles <- d94_summaries(results, data, paths)
  d94_plot_all(data, results, profiles, paths)
  capture.output(sessionInfo(), file = file.path(PROJECT_DIR, "plot_sessionInfo.txt"))
  message("PART 2 complete. Figures: ", paths$figures)
  message("Number of recorded solver events: ", nrow(results$warnings))
  message("For interpretation, start with 01_image_and_preprocessing and 03_frequency_profiles.")
  invisible(results)
}

if (isTRUE(getOption("d94.autorun", TRUE))) {
  if (!length(RUN_PARTS) || anyNA(RUN_PARTS) || !all(RUN_PARTS %in% c(1L, 2L))) {
    stop("RUN_PARTS must be 1, 2, or c(1,2).")
  }
  if (1L %in% RUN_PARTS) d94_part1()
  if (2L %in% RUN_PARTS) d94_part2()
}
